import mysql.connector
import datetime
from PyQt5 import uic,QtWidgets, Qt

#=======================================[VARIAVEIS]
APP = QtWidgets.QApplication([])

BD = mysql.connector.connect(host="localhost", user="root", passwd="r4qu3l", database="LojaRaquel")
cursor = BD.cursor()

CPFlogado = None
IDlogado = None
IDproduto = None
Pesquisa = None
DATANDO = datetime.date.today()
DATA = "{}{}{}".format(DATANDO.year, DATANDO.month, DATANDO.day)

#=======================================[JANELAS]
def close_all():
	HOME.close()
	LOGIN.close()
	CADCLIENTE.close()
	CADUSUARIO.close()
	PROCURAPRODUTO.close()
	MINHACONTA.close()
	MUDADADOS.close()
	DESEJASAIR.close()
	USUARIOBLOQUEADO.close()
	CARRINHOVAZIO.close()
	CARRINHO.close()
	OPERACAOREALIZADA.close()
	FINALIZACOMPRA.close()
	MEUSPEDIDOS.close()
	ERROOPERACAO.close()
	CERTEZA.close()
	
#---------------------------------------
def tela_home():
	close_all()	
	close_all2()
	HOME.show()
def tela_login():
	LOGIN.L1.setText("")
	LOGIN.L2.setText("")
	LOGIN.Le1.setText("")
	LOGIN.Le2.setText("")
	LOGIN.Le3.setText("")
	COMPRAASSISTIDA.L2S.setText("")
	COMPRAASSISTIDA.L3S.setText("")
	close_all()
	LOGIN.show()
def tela_cadcliente():
	CADCLIENTE.L1.setText("")
	CADCLIENTE.L3.setText("")
	CADCLIENTE.L4.setText("")
	CADCLIENTE.L6.setText("")
	CADCLIENTE.L7.setText("")
	CADCLIENTE.L8.setText("")
	CADCLIENTE.Le1.setText("")
	CADCLIENTE.Le2.setText("")
	CADCLIENTE.Le3.setText("")
	CADCLIENTE.Le4.setText("")
	CADCLIENTE.Le5.setText("")
	CADCLIENTE.Le6.setText("")
	close_all()
	CADCLIENTE.show()
def tela_cadusuario():
	CADUSUARIO.L1.setText(CPFlogado)
	CADUSUARIO.L2.setText("")
	CADUSUARIO.L3.setText("")
	CADUSUARIO.Le1.setText("")
	CADUSUARIO.Le2.setText("")
	close_all()
	CADUSUARIO.show()
def tela_procuraproduto():
	global Pesquisa
	Pesquisa = PROCURAPRODUTO.L1.text()	
	close_all()
	PROCURAPRODUTO.show()
	Mostra_Produtos()	
def tela_minhaconta():
	close_all()

	global CPFlogado
	
	A = "SELECT * from Pessoa where CPF_P = %s"
	B = (CPFlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()

	nome = resultado[0][1]
	datando = resultado[0][8]
	cpfando = resultado[0][0]
	telefando = resultado[0][2]
	estado = resultado[0][3]
	cidade = resultado[0][5]
	bairro = resultado[0][4]
	end = resultado[0][6]
	email = resultado[0][7]

	data = "{}/{}/{}".format(datando.day,datando.month, datando.year)
	cpf = "{}.{}.{}-{}".format(cpfando[:3], cpfando[3:6], cpfando[6:9], cpfando[9:])
	tel = "({}){} - {}".format(telefando[:2], telefando[2:7], telefando[7:])

	MINHACONTA.LN1.setText(nome) 
	MINHACONTA.LN2.setText(data)
	MINHACONTA.LN3.setText(cpf)
	MINHACONTA.LN4.setText(tel)
	MINHACONTA.LN5.setText(estado)
	MINHACONTA.LN6.setText(cidade)
	MINHACONTA.LN7.setText(bairro)
	MINHACONTA.LN8.setText(end)
	MINHACONTA.LN9.setText(email)

	#-------Preenche a próxima também:
	MUDADADOS.LN1.setText(nome) 
	MUDADADOS.LN2.setText(data) #NO CHANGE
	MUDADADOS.LN3.setText(cpf) #NO CHANGE
	MUDADADOS.LN4.setText(telefando)
	MUDADADOS.LN5.setText(estado)
	MUDADADOS.LN6.setText(cidade)
	MUDADADOS.LN7.setText(bairro)
	MUDADADOS.LN8.setText(end)
	MUDADADOS.LN9.setText(email)
	MUDADADOS.LN9_2.setText("")

	MINHACONTA.show()
def tela_mudadados():
	close_all()
	MUDADADOS.show()
def tela_desejasair():
	DESEJASAIR.show()
def tela_certeza():
	CERTEZA.show()
def tela_usuariobloqueado():
	USUARIOBLOQUEADO.show()
def tela_operacaorealizada():
	OPERACAOREALIZADA.show()
def tela_errooperacao():
	ERROOPERACAO.show()
def tela_carrinhovazio():
	close_all()
	CARRINHOVAZIO.show()
def tela_carrinho():
	close_all()
	Mostra_Carrinho()
	CARRINHO.show()
def tela_finalizacompra():
	global CPFlogado
	global IDlogado

	A = "SELECT ID_cart FROM ClienteWEB WHERE ID_Cliente = %s;"
	B = (IDlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDcart = resultado[0][0]

	flag = Verifica_Carrinho(IDcart)
	if flag == 1:
		tela_errooperacao()
		return
		
	A = "SELECT Estado_P, Cidade_P, Bairro_P, Endereco_P FROM Pessoa WHERE CPF_P = %s;"
	B = (CPFlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()

	estado = resultado[0][0]
	cidade = resultado[0][1]
	bairro = resultado[0][2]
	endereco = resultado[0][3]

	FINALIZACOMPRA.LN5.setText(estado)
	FINALIZACOMPRA.LN6.setText(cidade)
	FINALIZACOMPRA.LN7.setText(bairro)
	FINALIZACOMPRA.LN8.setText(endereco)

	subtotal = CARRINHO.T5.text()
	FINALIZACOMPRA.T5.setText(subtotal)

	total = CARRINHO.T7.text()
	FINALIZACOMPRA.T7.setText(total)

	close_all()
	FINALIZACOMPRA.show()
def tela_meuspedidos():
	close_all()
	Mostra_Pedidos()
	MEUSPEDIDOS.show()
#---------------------------------------
def close_all2():
	HOME.close()
	LOGIN.close()
	DESEJASAIR.close()
	HOMEFUNCIONARIO.close()
	ADM.close()
	MINHAFUNCCONTA.close()
	MUDAFUNCDADOS.close()
	CADASTROFUNCLI.close()
	BUSCACLIENTE.close()
	GERENCIAUSUARIO.close()
	COMPRAASSISTIDA.close()
	DADOSCLIENTE.close()
	CADASTRARPRODUTO.close()
	ESTOCARPRODUTO.close()
	COMPRAASSISTIDAFINALIZA.close()
	BUSCAPEDIDO.close()
	ATUALIZAPEDIDO.close()
	INSERIRPAGAMENTO.close()
	CADASTROFUNCIONARIO.close()
	BUSCAFUNCIONARIO.close()
	VENDAS.close()

#---------------------------------------
def tela_homefuncionario():
	close_all2()
	BUSCAPEDIDO.L1.setText("")
	HOMEFUNCIONARIO.show()
def tela_adm():
	close_all2()
	ADM.L1.setText("")
	ADM.L1_2.setText("")
	ADM.L1_3.setText("")
	ADM.show()
def tela_minhafuncconta():
	close_all2()
	global CPFlogado
	
	A = "SELECT CPF_P, Nome_P, Telefone_P, Estado_P, Bairro_P, Cidade_P, Endereco_P, Login_Func, Nascimento_P from Pessoa NATURAL JOIN Funcionario where CPF_P = %s"
	B = (CPFlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()

	nome = resultado[0][1]
	datando = resultado[0][8]
	cpfando = resultado[0][0]
	telefando = resultado[0][2]
	estado = resultado[0][3]
	cidade = resultado[0][5]
	bairro = resultado[0][4]
	end = resultado[0][6]
	email = resultado[0][7]

	data = "{}/{}/{}".format(datando.day,datando.month, datando.year)
	cpf = "{}.{}.{}-{}".format(cpfando[:3], cpfando[3:6], cpfando[6:9], cpfando[9:])
	tel = "({}){} - {}".format(telefando[:2], telefando[2:7], telefando[7:])

	MINHAFUNCCONTA.LN1.setText(nome) 
	MINHAFUNCCONTA.LN2.setText(data)
	MINHAFUNCCONTA.LN3.setText(cpf)
	MINHAFUNCCONTA.LN4.setText(tel)
	MINHAFUNCCONTA.LN5.setText(estado)
	MINHAFUNCCONTA.LN6.setText(cidade)
	MINHAFUNCCONTA.LN7.setText(bairro)
	MINHAFUNCCONTA.LN8.setText(end)
	MINHAFUNCCONTA.LN9.setText(email)

	#-------Preenche a próxima também:
	MUDAFUNCDADOS.LN1.setText(nome) 
	MUDAFUNCDADOS.LN2.setText(data) #NO CHANGE
	MUDAFUNCDADOS.LN3.setText(cpf) #NO CHANGE
	MUDAFUNCDADOS.LN4.setText(telefando)
	MUDAFUNCDADOS.LN5.setText(estado)
	MUDAFUNCDADOS.LN6.setText(cidade)
	MUDAFUNCDADOS.LN7.setText(bairro)
	MUDAFUNCDADOS.LN8.setText(end)
	MUDAFUNCDADOS.LN9.setText(email) #NO CHANGE
	MUDAFUNCDADOS.LN9_2.setText("")

	MINHAFUNCCONTA.show()
def tela_mudafuncdados():
	close_all2()
	MUDAFUNCDADOS.show()
def tela_cadastrofuncli():
	close_all2()
	CADASTROFUNCLI.show()
def tela_buscacliente():
	close_all2()
	Mostra_Clientes()
	BUSCACLIENTE.show()
def tela_gerenciausuario():
	linha = BUSCACLIENTE.TW.currentRow()
	if linha == -1:
		return
	IDcliente = BUSCACLIENTE.TW.item(linha, 0).text()

	A = "SELECT User_WEB, Status_WEB FROM ClienteWEB WHERE ID_Cliente = %s;"
	B = (IDcliente,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0:
		return

	user = resultado[0][0]
	status = resultado[0][1]
	
	GERENCIAUSUARIO.L1.setText(IDcliente)
	GERENCIAUSUARIO.L3.setText(user)
	GERENCIAUSUARIO.L4.setText(status)

	close_all2()
	GERENCIAUSUARIO.show()
def tela_dadoscliente():
	linha = BUSCACLIENTE.TW.currentRow()
	if linha == -1:
		return
	Tel= BUSCACLIENTE.TW.item(linha, 2).text()

		
	A = "SELECT * from Pessoa where Telefone_P = %s"
	B = (Tel,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()

	nome = resultado[0][1]
	datando = resultado[0][8]
	cpf = resultado[0][0]
	tel = resultado[0][2]
	estado = resultado[0][3]
	cidade = resultado[0][5]
	bairro = resultado[0][4]
	end = resultado[0][6]
	email = resultado[0][7]

	data = "{}/{}/{}".format(datando.day,datando.month, datando.year)
	
	DADOSCLIENTE.LN1.setText(nome) 
	DADOSCLIENTE.LN2.setText(data)
	DADOSCLIENTE.LN3.setText(cpf)
	DADOSCLIENTE.LN4.setText(tel)
	DADOSCLIENTE.LN5.setText(estado)
	DADOSCLIENTE.LN6.setText(cidade)
	DADOSCLIENTE.LN7.setText(bairro)
	DADOSCLIENTE.LN8.setText(end)
	DADOSCLIENTE.LN9.setText(email)
	close_all2()
	DADOSCLIENTE.show()
def tela_compraassistida():
	close_all2()
	Buscar_Produto()
	Mostra_Cart_Cliente()
	COMPRAASSISTIDA.show()
def tela_cadastrarproduto():
	CADASTRARPRODUTO.L1.setText("")
	CADASTRARPRODUTO.L2.setText("")
	close_all2()
	CADASTRARPRODUTO.show()
def tela_estocarproduto():
	ESTOCARPRODUTO.L3.setText("")
	ESTOCARPRODUTO.L4.setText("")
	close_all2()
	ESTOCARPRODUTO.show()
def tela_compraassistidafinaliza():
	cpf = COMPRAASSISTIDA.L1.text()
	IDcart = COMPRAASSISTIDA.L2S.text()

	flag = Verifica_Carrinho(int(IDcart))
	if flag == 1:
		tela_errooperacao()
		return
		
	A = "SELECT Estado_P, Cidade_P, Bairro_P, Endereco_P FROM Pessoa WHERE CPF_P = %s;"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()

	estado = resultado[0][0]
	cidade = resultado[0][1]
	bairro = resultado[0][2]
	endereco = resultado[0][3]

	COMPRAASSISTIDAFINALIZA.LN5.setText(estado)
	COMPRAASSISTIDAFINALIZA.LN6.setText(cidade)
	COMPRAASSISTIDAFINALIZA.LN7.setText(bairro)
	COMPRAASSISTIDAFINALIZA.LN8.setText(endereco)

	subtotal = COMPRAASSISTIDA.L3S.text()
	COMPRAASSISTIDAFINALIZA.T5.setText(subtotal)

	total = float(subtotal) + 15.90
	total = round(total,2)
	COMPRAASSISTIDAFINALIZA.T7.setText(str(total))

	COMPRAASSISTIDAFINALIZA.show()
	close_all2()
	COMPRAASSISTIDAFINALIZA.show()
def tela_buscapedido():
	close_all2()

	busca = BUSCAPEDIDO.L1.text()
	if busca == "":
		A = "SELECT * FROM Pedidos ORDER BY ID_Pdd;"
		cursor.execute(A)
	else:
		A = "SELECT * FROM Pedidos WHERE ID_Conta = %s ORDER BY ID_Pdd;"
		B = (busca,)
		cursor.execute(A,B)
	
	Resultado = cursor.fetchall()
	size = len(Resultado)
	if size == 0:
		BUSCAPEDIDO.show()
		return

	BUSCAPEDIDO.TW.setRowCount(size)
	BUSCAPEDIDO.TW.setColumnCount(5)

	BUSCAPEDIDO.TW.setColumnWidth(0,30)
	BUSCAPEDIDO.TW.setColumnWidth(1,100)
	BUSCAPEDIDO.TW.setColumnWidth(2,300)
	BUSCAPEDIDO.TW.setColumnWidth(3,80)
	BUSCAPEDIDO.TW.setColumnWidth(4,100)


	for i in range (size):
		for j in range (5):
			BUSCAPEDIDO.TW.setItem(i,j,QtWidgets.QTableWidgetItem(str(Resultado[i][j])))
			BUSCAPEDIDO.TW.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)

	

	BUSCAPEDIDO.show()
def tela_atualizastatus(): #FUNC/PEDIDO
	close_all2()
	ATUALIZAPEDIDO.show()
def tela_inserirpagamento(): #FUNC/PAGAMENTO
	close_all2()
	INSERIRPAGAMENTO.show()
def tela_cadastrofuncionario():
	close_all2()
	CADASTROFUNCIONARIO.L1.setText("")
	CADASTROFUNCIONARIO.L3.setText("")
	CADASTROFUNCIONARIO.L4.setText("")
	CADASTROFUNCIONARIO.L6.setText("")
	CADASTROFUNCIONARIO.L7.setText("")
	CADASTROFUNCIONARIO.L8.setText("")
	CADASTROFUNCIONARIO.L9.setText("")
	CADASTROFUNCIONARIO.L9_2.setText("")
	CADASTROFUNCIONARIO.show()
def tela_listafuncionarios():
	close_all2()

	A = "SELECT ID_Func, Nome_P, Login_Func, Telefone_P, CPF_P FROM Funcionario NATURAL JOIN Pessoa;"
	cursor.execute(A)
		
	Resultado = cursor.fetchall()
	size = len(Resultado)
	
	BUSCAFUNCIONARIO.TW.setRowCount(size)
	BUSCAFUNCIONARIO.TW.setColumnCount(5)

	BUSCAFUNCIONARIO.TW.setColumnWidth(0,20)
	BUSCAFUNCIONARIO.TW.setColumnWidth(1,200)
	BUSCAFUNCIONARIO.TW.setColumnWidth(2,250)
	BUSCAFUNCIONARIO.TW.setColumnWidth(3,130)
	BUSCAFUNCIONARIO.TW.setColumnWidth(4,80)

	for i in range (size):
		for j in range (5):
			BUSCAFUNCIONARIO.TW.setItem(i,j,QtWidgets.QTableWidgetItem(str(Resultado[i][j])))
			BUSCAFUNCIONARIO.TW.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)

	BUSCAFUNCIONARIO.show()
def tela_vendas():
	close_all2()

	A = "SELECT Tipo_Pgmt, count(ID_Pgmt) as qtd FROM Pagamentos GROUP BY Tipo_Pgmt  HAVING qtd  >= ALL(SELECT count(ID_Pgmt) as qtd FROM Pagamentos GROUP BY Tipo_Pgmt);"
	cursor.execute(A)
	resultado = cursor.fetchall()
	size = len(resultado)

	if size > 0:
		Forma = resultado[0][0]
		VENDAS.T1.setText(Forma)
	else:
		VENDAS.T1.setText("Sem Pagamentos")

	A = "SELECT year(Data_Pdd), sum(Valor_Pdd) FROM Pedidos WHERE Status_Pdd = 'Finalizado' GROUP BY year(Data_Pdd);"
	cursor.execute(A)
	resultado = cursor.fetchall()
	size = len(resultado)

	soma = 0
	if size  == 0:
		media = 0
	else:
		for i in range (size):
			soma += resultado[i][1]
		media = soma/size

	VENDAS.T2.setText(str(media))

	A = "SELECT month(Data_Pdd), year(Data_Pdd), count(ID_Pdd) as qtd FROM Pedidos WHERE Status_Pdd = 'Finalizado' GROUP BY year(Data_Pdd),month(Data_Pdd) HAVING qtd >= ALL (SELECT count(ID_Pdd) as qtd FROM Pedidos WHERE Status_Pdd = 'Finalizado' GROUP BY year(Data_Pdd),month(Data_Pdd));"
	cursor.execute(A)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size >0:
		mes = resultado[0][0]
		ano = resultado[0][1]
	else:
		mes = 0
		ano = 0

	data = "{}/{}".format(mes, ano)

	VENDAS.T3.setText(data)

	
	A = "SELECT year(Data_Pdd), month(Data_Pdd),ID_Pdd, Valor_Pdd FROM Pedidos WHERE Status_Pdd = 'Finalizado' ORDER BY year(Data_Pdd), month(Data_Pdd);"
	cursor.execute(A)
	
	Resultado = cursor.fetchall()
	size = len(Resultado)
	
	VENDAS.TW.setRowCount(size)
	VENDAS.TW.setColumnCount(4)

	VENDAS.TW.setColumnWidth(0,100)
	VENDAS.TW.setColumnWidth(1,100)
	VENDAS.TW.setColumnWidth(2,300)
	VENDAS.TW.setColumnWidth(3,100)
	
	for i in range (size):
		for j in range (4):
			VENDAS.TW.setItem(i,j,QtWidgets.QTableWidgetItem(str(Resultado[i][j])))
			VENDAS.TW.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)
	VENDAS.show()

#=======================================[MSQLmódulos]
#-------------[INSERT]-------------------
def Novo_Cliente(cpf):
	A = "INSERT INTO Cliente values(null, %s);"
	B = (cpf,)
	cursor.execute(A,B)
	#------------[CARRINHO]-------------
	A = "SELECT ID_Cliente from Cliente where CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDcliente = resultado[0][0]

	A = "INSERT INTO Conta values(null, %s);"
	B = (IDcliente,)
	cursor.execute(A,B)
	#------------[CARRINHO]-------------
	A = "SELECT ID_Conta from Conta where ID_Cliente = %s"
	B = (IDcliente,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDconta = resultado[0][0]

	A = "INSERT INTO Carrinho values(null, %s);"
	B = (IDconta,)
	cursor.execute(A,B)
	BD.commit()

def Novo_Funcionario(email, senha, cpf):
	A = "INSERT INTO Funcionario values(null, %s, %s, %s);"
	B = (email, senha, cpf)
	cursor.execute(A,B)
	BD.commit()

def Coloca_Carrinho(IDproduto, IDcart):
	A = "INSERT INTO Carrega_Item values(%s, %s, 1);" 
	B = (IDproduto,IDcart)
	cursor.execute(A,B)
	BD.commit()	

def Inserir_Pagamento(IDpedido, Forma, Valor):
	DATANDO = datetime.date.today()
	DATA = "{}{}{}".format(DATANDO.year, DATANDO.month, DATANDO.day)
	cursor.execute("INSERT INTO Pagamentos Values(null, {}, '{}', {},{});".format(IDpedido, Forma, float(Valor), DATA))
	BD.commit()

#-------------[UPDATE]-------------------
def Atualizar_Usuario(IDcliente, Status):	
	A = "UPDATE ClienteWEB SET Status_WEB = %s WHERE ID_Cliente = %s;"
	B = (Status, IDcliente)
	cursor.execute(A,B)
	BD.commit()

def Altera_qtd_Produto(IDproduto, IDcart, qtd):
	A = "UPDATE Carrega_Item SET Qtd_Pdt = %s WHERE ID_Cart = %s and ID_Pdt = %s;"
	B = (qtd, IDcart, IDproduto)
	cursor.execute(A,B)
	BD.commit()

def Valor_Pedido(IDPedido,Valor):
	cursor.execute("UPDATE Pedidos SET Valor_Pdd = {} WHERE ID_Pdd = {};".format(Valor, IDPedido))
	BD.commit()

def Status_Pedido(IDPedido, Status):
	A = "UPDATE Pedidos SET Status_Pdd = %s WHERE ID_Pdd = %s;"
	B = (Status, IDPedido)
	cursor.execute(A,B)
	BD.commit()

def Atualiza_Estoque(IDproduto, qtd):
	A = "UPDATE Produto SET Estoque_Pdt = Estoque_Pdt + %s WHERE ID_Pdt = %s;"
	B = (qtd, IDproduto)
	cursor.execute(A,B)
	BD.commit()


def Relatorio_Produto(IDfunc, IDpdt, Valor, Qtd):
	DATANDO = datetime.date.today()
	DATA = "{}{}{}".format(DATANDO.year, DATANDO.month, DATANDO.day)
	cursor.execute("INSERT INTO AT_Produto Values({},{},{},{},{});".format(IDfunc, IDpdt, float(Valor), Qtd, DATA))
	BD.commit()
def Relatorio_Pedido(IDfunc, IDpdd, Status):
	DATANDO = datetime.date.today()
	DATA = "{}{}{}".format(DATANDO.year, DATANDO.month, DATANDO.day)
	cursor.execute("INSERT INTO At_Pedido Values({},{},{},'{}');".format(IDfunc, IDpdd, DATA, Status))
	BD.commit()
def Relatorio_Cliente(IDfunc, IDcliente, Action):
	DATANDO = datetime.date.today()
	DATA = "{}{}{}".format(DATANDO.year, DATANDO.month, DATANDO.day)
	cursor.execute("INSERT INTO At_Cliente Values({},{},'{}',{});".format(IDfunc, IDcliente, Action, DATA))
	BD.commit()
	
#-------------[DELETE]-------------------
def Limpa_Carrinho(IDCart):
    A = "DELETE FROM Carrega_Item WHERE ID_Cart = %s;"
    B = (IDCart,)
    cursor.execute(A,B)
    BD.commit()

def Excluir_Pessoa(cpf):
	A = "DELETE from Pessoa WHERE CPF_P = %s;"
	B = (cpf,)
	cursor.execute(A,B)
	BD.commit()

def Excluir_Cliente(cpf):
	A = "DELETE from Cliente WHERE CPF_P = %s;"
	B = (cpf,)  
	cursor.execute(A,B)  
	BD.commit()

def Excluir_Funcionario(cpf):
	A = "DELETE from Funcionario WHERE CPF_P = %s;"
	B = (cpf,) 
	cursor.execute(A,B)   
	BD.commit()

def Tirar_Carrinho(IDcart, IDproduto):
	A = "DELETE from Carrega_Item WHERE ID_Pdt = %s and ID_Cart = %s;"
	B = (IDproduto, IDcart)
	cursor.execute(A,B)   
	BD.commit()

#---------[FAZER PEDIDO]-----------------
def Verifica_Carrinho(IDcart):
	A = "SELECT Nome_Pdt FROM Carrega_Item NATURAL JOIN Produto WHERE ID_Cart = %s and Qtd_Pdt > Estoque_Pdt;"
	B = (IDcart,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size > 0:
		return 1
	return 0 
	

def Pega_Item(IDProduto, IDPedido):
	A = "SELECT ID_Item FROM Itens WHERE ID_Pdt = %s AND ID_Pdd IS NULL LIMIT 1;"
	B = (IDProduto,)
	cursor.execute(A,B)
	R = cursor.fetchall()
	IDItem = R[0][0]
	#-------------------------------{Marca Produto}
	A = "DELETE FROM Itens WHERE ID_Item = %s;"
	B = (IDItem,)
	cursor.execute(A,B)

	A = "INSERT INTO Itens Values(%s, %s, %s);"
	B = (IDItem, IDProduto, IDPedido)
	cursor.execute(A,B)
	#-------------------------------{Abate do Estoque}    
	A = "UPDATE Produto SET Estoque_Pdt = Estoque_Pdt-1 WHERE ID_Pdt = %s;"
	B = (IDProduto,)
	cursor.execute(A,B)

	BD.commit()

def Fazer_Pedido(IDCart, IDConta):
	global DATA
	#-------------------------------{Pega Carrinho}                       
	A = "SELECT ID_Pdt, Qtd_Pdt, Nome_Pdt, Preco_Pdt FROM Carrega_Item NATURAL JOIN Produto WHERE ID_Cart = %s;"
	B = (IDCart,)
	cursor.execute(A,B)
	P = cursor.fetchall()
	size = len(P)
	#-------------------------------{Verifica Compra}   
	for i in range(size):                        
	    flag = Verifica_Estoque(P[i][0], P[i][1])
	    if flag == 1:
	        break

	if flag == 1:
	    return
	#-------------------------------{Cria Pedido}
	A = "INSERT INTO Pedidos Values(null, %s, 'Em processamento', 0, %s);"
	B = (IDConta, DATA)
	cursor.execute(A,B)
	BD.commit()

	A = "SELECT max(ID_Pdd) FROM Pedidos WHERE ID_Conta = %s;"
	B = (IDConta,)
	cursor.execute(A,B)
	R = cursor.fetchall()
	IDPedido = R[0][0]
	Valor = 0
	Valor = float(Valor)

	for i in range(size): 
	    qtd = int(P[i][1])
	    preco = float(P[i][3])
	    for j in range(qtd):
	        Pega_Item(P[i][0], IDPedido)
	    Valor = Valor + float(qtd)*(preco)	    
	#-------------------------------{Finaliza Pedido}

	Valor_Pedido(IDPedido,Valor)
	Limpa_Carrinho(IDCart)
	Status_Pedido(IDPedido, "Confirmado")
	return Valor

#-------------[CHECK]--------------------
def Verifica_Estoque(IDproduto, qtd):
    A = "SELECT Estoque_Pdt FROM Produto WHERE ID_Pdt = %s;"
    B = (IDproduto,)
    cursor.execute(A,B)
    R = cursor.fetchall()
    if R[0][0] < qtd:
        return 1
    else:
        return 0

def Verifica_Produto_Carrinho(IDproduto, IDcart):
	A = "SELECT Qtd_Pdt FROM Carrega_Item WHERE ID_Pdt = %s and ID_Cart = %s;"
	B = (IDproduto, IDcart)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size >0:
		return 1
	return 0
#=======================================[ACTIONS]
#--------------[CADASTRO]---------------
def Cadastrar_Pessoa():	# Cadastrar Pessoa
	#-----------Tela Cliente
	CADCLIENTE.Le1.setText("")
	CADCLIENTE.Le2.setText("")
	CADCLIENTE.Le3.setText("")
	CADCLIENTE.Le4.setText("")
	CADCLIENTE.Le5.setText("")
	CADCLIENTE.Le6.setText("")
	#-----------Tela Funcionario
	CADASTROFUNCLI.Le1.setText("")
	CADASTROFUNCLI.Le2.setText("")
	CADASTROFUNCLI.Le3.setText("")
	CADASTROFUNCLI.Le4.setText("")
	CADASTROFUNCLI.Le5.setText("")
	CADASTROFUNCLI.Le6.setText("")
	
	nome = CADCLIENTE.L1.text()
	datando = CADCLIENTE.L2.date()
	data = "{:04d}{:02d}{:02d}".format(datando.year(), datando.month(), datando.day())
	cpf = CADCLIENTE.L3.text()
	tel = CADCLIENTE.L4.text()
	estado = CADCLIENTE.L5.currentText()
	cidade = CADCLIENTE.L6.text()
	bairro = CADCLIENTE.L7.text()
	end = CADCLIENTE.L8.text()
	
	flag = 0

	#---------Não permite cadastro:
	if cpf == "":
		CADCLIENTE.Le2.setText("*")
		CADASTROFUNCLI.Le2.setText("*")
		flag = 1
	else:
		A = "SELECT * from Pessoa where CPF_P = %s"
		B = (cpf,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		size = len(resultado)

		if size > 0:
			CADCLIENTE.Le2.setText("CPF já cadastrado")
			return cpf

	if nome == "":
		CADCLIENTE.Le1.setText("*")
		CADASTROFUNCLI.Le1.setText("*")
		flag = 1

	if tel == "":
		CADCLIENTE.Le3.setText("*")
		CADASTROFUNCLI.Le3.setText("*")
		flag = 1
	else:
		A = "SELECT CPF_P from Pessoa where Telefone_P = %s"
		B = (tel,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		size = len(resultado)
		if size > 0:
			CADCLIENTE.Le3.setText("Telefone já cadastrado")
			flag = 1

	if cidade == "":
		CADCLIENTE.Le4.setText("*")
		CADASTROFUNCLI.Le4.setText("*")
		flag = 1

	if bairro == "":
		CADCLIENTE.Le5.setText("*")
		CADASTROFUNCLI.Le5.setText("*")
		flag = 1

	if end == "":
		CADCLIENTE.Le6.setText("*")
		CADASTROFUNCLI.Le6.setText("*")
		flag = 1

	if cpf.isdigit() == 0 or len(cpf) < 11:
		CADCLIENTE.Le2.setText("CPF inválido")
		CADASTROFUNCLI.Le2.setText("CPF inválido")
		flag = 1

	if tel.isdigit() == 0 or len(cpf) < 11:
		CADCLIENTE.Le3.setText("Telefone inválido")
		CADASTROFUNCLI.Le3.setText("Telefone inválido")
		flag = 1

	if flag == 1:
		return flag

	A = "INSERT INTO Pessoa values(%s, %s, %s, %s, %s, %s, %s, null, %s);" 
	B = (cpf,nome, tel, estado, cidade, bairro, end, data)
	cursor.execute(A,B)
	BD.commit()

	return cpf

def Criar_Cliente(): #Tenta cadastrar pessoa e Tenta cadastrar Cliente
	CADCLIENTE.Le7.setText("")	

	cpf = Cadastrar_Pessoa() #Cadastra/Aproveita

	if cpf == 1:
		return

	A = "SELECT CPF_P from Cliente where CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size > 0: 
		CADCLIENTE.Le7.setText("Conta existente!")
		return

	else: 
		Novo_Cliente(cpf)
		CPFlogado = cpf
		tela_cadusuario()

def Cadastrar_Funcionario():
	nome = CADASTROFUNCIONARIO.L1.text()
	datando = CADASTROFUNCIONARIO.L2.date()
	data = "{:04d}{:02d}{:02d}".format(datando.year(), datando.month(), datando.day())
	cpf = CADASTROFUNCIONARIO.L3.text()
	tel = CADASTROFUNCIONARIO.L4.text()
	estado = CADASTROFUNCIONARIO.L5.currentText()
	cidade = CADASTROFUNCIONARIO.L6.text()
	bairro = CADASTROFUNCIONARIO.L7.text()
	end = CADASTROFUNCIONARIO.L8.text()
	email = CADASTROFUNCIONARIO.L9.text()
	senha = CADASTROFUNCIONARIO.L9_2.text()

	A = "SELECT CPF_P FROM Pessoa WHERE CPF_P = %s;"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)

	if size > 0:
		Novo_Funcionario(email, senha, cpf)
	
	else:
		A = "INSERT INTO Pessoa values(%s, %s, %s, %s, %s, %s, %s, null, %s);" 
		B = (cpf,nome, tel, estado, cidade, bairro, end, data)
		cursor.execute(A,B)
		BD.commit()
		Novo_Funcionario(email, senha, cpf)

	tela_homefuncionario()
	tela_operacaorealizada() #Funcionario Cadastra Funcionario

def Func_CriaCliente():
	CADASTROFUNCLI.Le7.setText("")

	#-------Rebatimento na Janela Cadastro Cliente
	nome = CADASTROFUNCLI.L1.text()
	datando = CADASTROFUNCLI.L2.date()
	cpf = CADASTROFUNCLI.L3.text()
	tel = CADASTROFUNCLI.L4.text()
	estado = CADASTROFUNCLI.L5.currentText()
	cidade = CADASTROFUNCLI.L6.text()
	bairro = CADASTROFUNCLI.L7.text()
	end = CADASTROFUNCLI.L8.text()

	CADCLIENTE.L1.setText(nome)
	CADCLIENTE.L2.setDate(datando)
	CADCLIENTE.L3.setText(cpf)
	CADCLIENTE.L4.setText(tel)
	CADCLIENTE.L5.setCurrentText(estado)
	CADCLIENTE.L6.setText(cidade)
	CADCLIENTE.L7.setText(bairro)
	CADCLIENTE.L8.setText(end)
	
	cpf = Cadastrar_Pessoa() #Cadastra/Aproveita

	if cpf == 1:
		return

	A = "SELECT CPF_P from Cliente where CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size > 0: 
		CADASTROFUNCLI.Le7.setText("Conta existente!")
		return

	else: 
		Novo_Cliente(cpf)
		tela_homefuncionario() #Cria Cliente #Funcionario Cria Cliente

def Criar_Usuario(): #Cliente criar usuário
	CADUSUARIO.Le1.setText("")
	CADUSUARIO.Le2.setText("")
	CADUSUARIO.Le1.setText("")

	cpf = CADUSUARIO.L1.text()
	email = CADUSUARIO.L2.text()
	senha = CADUSUARIO.L3.text()

	flag = 0

	if cpf == "":
	    CADUSUARIO.Le1.setText("*")
	    flag = 1
	else:
		A = "SELECT CPF_P, ID_Cliente, ID_Cart from Cliente NATURAL JOIN Conta NATURAL JOIN Carrinho where CPF_P = %s;"
		B = (cpf,)
		cursor.execute(A,B)
		R = cursor.fetchall()
		size = len(R)

		if size == 0:
			CADUSUARIO.Le1.setText("CPF não cadastrado")
			flag = 1
		else:
			IDcliente = R[0][1]
			IDcart = R[0][2]
			
			A = "SELECT ID_Cliente FROM ClienteWEB WHERE ID_Cliente= %s;"
			B = (IDcliente,)
			cursor.execute(A,B)
			resultado = cursor.fetchall()
			size = len(resultado)
			if size > 0:
				CADUSUARIO.Le1.setText("Usuário já cadastrado")
				flag = 1

	if email == "":
	    CADUSUARIO.Le2.setText("*")
	    flag = 1
	else:
		A = "SELECT Email_P from Pessoa where Email_P = %s;"
		B = (email,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		size = len(resultado)

		if size > 0:
			CADUSUARIO.Le2.setText("Email já cadastrado")
			flag = 1


	if senha == "":
	    CADUSUARIO.Le3.setText("*")
	    flag = 1

	if flag == 1:
		return

	A = "UPDATE Pessoa SET Email_P = %s WHERE CPF_P = %s;"
	B = (email, cpf)
	cursor.execute(A,B)

	A = "INSERT INTO ClienteWEB values(%s, %s, 'Novo',%s, %s);"
	B = (email, senha, IDcliente, IDcart)
	cursor.execute(A,B)
	#-------Salvar no BD:
	BD.commit()

	tela_login()

def Excluir_MinhaConta():
	global CPFlogado
	A = "SELECT ID_Func FROM Funcionario WHERE CPF_P = %s"
	B = (CPFlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size > 0: #é funcionario
		Excluir_Cliente(CPFlogado)
	else:
		Excluir_Pessoa(CPFlogado)
	
	tela_home()
	return #Cliente Exclui Própria Conta

def Cadastrar_Produto():
	global IDlogado
	CADASTRARPRODUTO.Le1.setText("")
	CADASTRARPRODUTO.Le2.setText("")

	#-----------Pega valores dos campos:
	nome = CADASTRARPRODUTO.L1.text()
	desc = CADASTRARPRODUTO.L2.text()
	cat = CADASTRARPRODUTO.L3.currentText()
	preco = CADASTRARPRODUTO.L4.value()

	flag = 0

	if nome == "":
		CADASTRARPRODUTO.Le1.setText("*")
		flag = 1

	if preco == 0:
		CADASTRARPRODUTO.Le2.setText("Preço Inválido!")
		flag = 1

	else: #-----------Verifica se nome repete:
		A = "SELECT ID_Pdt from Produto where Nome_Pdt = %s"
		B = (nome,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		size = 	len(resultado)
		if size > 0: #Produto já cadastrado
			CADASTRARPRODUTO.Le1.setText("Produto já cadastrado")
			flag = 1

	if flag == 1:
		return

	#-----------Insere valores nas tabelas:
	A = "INSERT INTO Produto values(null, %s, %s, %s, %s, 0);"
	B = (nome, preco, desc, cat)
	cursor.execute(A,B)

	#-------Salvar no BD:
	BD.commit()
	tela_operacaorealizada() #Funcionario Cadastra Produto

def Estocar_Produto():
	global IDlogado
	#-----------Pega valores dos campos:
	IDp = ESTOCARPRODUTO.L1.text()
	qtd = ESTOCARPRODUTO.L3.text()
	precando = ESTOCARPRODUTO.L4.text()

	#-----------Verifica se nome repete:
	A = "SELECT Nome_Pdt, Preco_Pdt from Produto where ID_Pdt = %s"
	B = (IDp,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	if len(resultado) < 1: #Não existe o produto
		ESTOCARPRODUTO.Le1.setText("!!!")
		IDproduto_Nome()
		return
	value = resultado[0][1]
	#-----------Insere valores nas tabelas:
	if precando != '':
		preco = "{:2f}".format(float(precando))
		A = "UPDATE Produto SET Preco_Pdt = %s where ID_Pdt = %s;"
		B = (preco, IDp)
		cursor.execute(A,B)
		value = preco

	if qtd != '':
	    qtd = int(qtd)
	    for i in range(qtd):
	        A = "INSERT INTO Itens values(null, %s, null);"
	        B = (IDp,)
	        cursor.execute(A,B)
	    Atualiza_Estoque(IDp, qtd)
	else:
		qtd = 0
	#-------Salvar no BD:
	Relatorio_Produto(IDlogado, IDp, value, qtd)

	BD.commit()
	tela_operacaorealizada() #Funcionario estoca Produto

def Exc_Func():
	cpf = ADM.L1.text()

	A = "SELECT ID_Func FROM Funcionario WHERE CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0: #Errou!
		ADM.Le1.setText("CPF Inválido!")
		return

	A = "SELECT ID_Cliente FROM Cliente WHERE CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size > 0: #é cliente
		Excluir_Funcionario(cpf)
	else:
		Excluir_Pessoa(cpf)
	
	tela_homefuncionario()
	tela_operacaorealizada()
	return #Funcionario exclui Funcionario

def Exc_Cli():
	cpf = ADM.L1_2.text()

	A = "SELECT ID_Cliente FROM Cliente WHERE CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0: #Errou!
		ADM.Le1_2.setText("CPF Inválido!")
		return

	A = "SELECT ID_Func FROM Funcionario WHERE CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size > 0: #é funcionario
		Excluir_Cliente(cpf)
	else:
		Excluir_Pessoa(cpf)
	
	tela_homefuncionario()
	tela_operacaorealizada()
	return #Funcionario exclui cliente

def Exc_Tudo():
	cpf = ADM.L1_3.text()

	A = "SELECT CPF_P FROM Pessoa WHERE CPF_P = %s"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0: #Errou!
		ADM.Le1_3.setText("CPF Inválido!")
		return
	Excluir_Pessoa(cpf)
	tela_homefuncionario()
	tela_operacaorealizada()
	return #Funcionario exclui tudo



#---------------[ACESSO]----------------
def Login(): #Permite o acesso de cliente a area do cliente e funcionario a area do funcionario
	global IDlogado
	global CPFlogado
	email = LOGIN.L1.text()
	senha = LOGIN.L2.text()

	flag = 0

	if email == "":
		LOGIN.Le1.setText("*")
		flag = 1
	if senha == "":
		LOGIN.Le2.setText("*")
		flag = 1

	if flag == 1:
		return
	
	#------OU É FUNCIONARIO:
	A = "SELECT ID_Func, Senha_Func, CPF_P FROM Funcionario where Login_Func = %s"
	B = (email,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()

	size = len(resultado)

	if size > 0:
		if senha == resultado[0][1]:
			IDlogado = resultado[0][0]
			CPFlogado = resultado[0][2]
			tela_homefuncionario()
			return
		LOGIN.Le3.setText("Login/Senha inválido")
		return

	#-------OU É CLIENTE:
	A = "SELECT ID_Cliente, Senha_WEB, CPF_P, Status_WEB FROM ClienteWEB natural join Cliente where User_WEB = %s"
	B = (email,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()

	size = len(resultado)

	if size > 0:
		if senha == resultado [0][1]:
			if resultado[0][3] == 'Bloqueado':
				tela_usuariobloqueado()
				return
			else:
				IDlogado = resultado[0][0]
				CPFlogado = resultado[0][2]
				Atualizar_Usuario(IDlogado, "Ativo")
				tela_procuraproduto()
				return
			
		LOGIN.Le3.setText("Login/Senha inválido")
		return

	#--------ELSE:
	LOGIN.Le3.setText("Login/Senha inválido")
	return

def Logout(): #desloga da conta e limpa as globais
	global CPFlogado
	global IDlogado
	global Pesquisa
	global IDproduto
	global IDcart

	CPFlogado = None
	IDlogado = None
	Pesquisa = None
	IDproduto = None
	IDcart = None

	tela_home()

#-------------[VIZUALIZAR]--------------
def Visualiza_Carrinho(): #Cliente : Determina qual tela de carrinho sera exibida
	global IDlogado
	#-----------Procura o Carrinho de quem ta logado:
	A = "SELECT ID_Cart from ClienteWEB where ID_Cliente = %s"
	B = (IDlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDcart = resultado[0][0]

	#-----------Verifica se o carrinho tem item:
	A = "SELECT * from Carrega_Item where ID_Cart = %s"
	B = (IDcart,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0: #Carrinho Vazio
		tela_carrinhovazio()
		return
	tela_carrinho() #Carrinho com produto
	return

def Limpa_Produto(): #Cliente: Limpa o texto de visualizar produto
	PROCURAPRODUTO.T1.setText("")
	PROCURAPRODUTO.T2.setText("")
	PROCURAPRODUTO.T3.setText("")
	PROCURAPRODUTO.T4.setText("")
	PROCURAPRODUTO.T5.setText("")
	PROCURAPRODUTO.Le1.setText("")

def Mostra_Produtos():	#Cliente: Procura Produtos
	global Pesquisa
	Limpa_Produto()	
	cat1 = "N"
	cat2 = "N"
	cat3 = "N"

	if PROCURAPRODUTO.C1.isChecked():
		cat1 = "A"		
		
	if PROCURAPRODUTO.C2.isChecked():
		cat2 = "B"

	if PROCURAPRODUTO.C3.isChecked():
		cat3 = "C"

	if cat1 == "N" and cat2 == "N" and cat3 == "N":
		cat1 = "A"
		cat2 = "B"
		cat3 = "C"

	A = "SELECT ID_Pdt, Nome_Pdt, Preco_Pdt, Categoria_Pdt from Produto WHERE (Categoria_Pdt = '{}' or Categoria_Pdt = '{}' or Categoria_Pdt = '{}') and Nome_Pdt LIKE '%{}%';".format(cat1, cat2, cat3, Pesquisa)
	cursor.execute(A)
	Resultado = cursor.fetchall()
	size = len(Resultado)

	
	PROCURAPRODUTO.TW.setRowCount(size)
	PROCURAPRODUTO.TW.setColumnCount(4)

	PROCURAPRODUTO.TW.setColumnWidth(0,30)
	PROCURAPRODUTO.TW.setColumnWidth(1,300)
	PROCURAPRODUTO.TW.setColumnWidth(2,40)
	PROCURAPRODUTO.TW.setColumnWidth(3,30)


	for i in range (size):
		for j in range (4):
			PROCURAPRODUTO.TW.setItem(i,j,QtWidgets.QTableWidgetItem(str(Resultado[i][j])))
			PROCURAPRODUTO.TW.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)

	PROCURAPRODUTO.Le1.setText("")
	
	if size == 0:
		Limpa_Produto()
		return

def Buscar_Produto(): #Funcionario: Procura Produtos 
	busca = COMPRAASSISTIDA.L1_3.text()

	A = "SELECT ID_Pdt, Nome_Pdt, Preco_Pdt, Estoque_Pdt from Produto WHERE Nome_Pdt LIKE '%{}%';".format(busca)
	cursor.execute(A)
	Resultado = cursor.fetchall()
	size = len(Resultado)

	
	COMPRAASSISTIDA.TW.setRowCount(size)
	COMPRAASSISTIDA.TW.setColumnCount(4)

	COMPRAASSISTIDA.TW.setColumnWidth(0,30)
	COMPRAASSISTIDA.TW.setColumnWidth(1,200)
	COMPRAASSISTIDA.TW.setColumnWidth(2,40)
	COMPRAASSISTIDA.TW.setColumnWidth(3,30)

	for i in range (size):
		for j in range (4):
			COMPRAASSISTIDA.TW.setItem(i,j,QtWidgets.QTableWidgetItem(str(Resultado[i][j])))
			COMPRAASSISTIDA.TW.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)

def Visualiza_Produto(): #Cliente: Visualiza o produto que foi clicado na pesquisa
	global IDproduto
	
	linha = PROCURAPRODUTO.TW.currentRow()
	if linha == -1:
		return
	IDproduto = PROCURAPRODUTO.TW.item(linha, 0).text()

	A = ("SELECT Nome_Pdt, Categoria_Pdt, Descricao_Pdt, Preco_Pdt, Estoque_Pdt FROM Produto WHERE ID_Pdt = %s")
	B = (IDproduto,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	
	nome = resultado[0][0]
	cat = resultado[0][1]
	desc = resultado[0][2]
	preco = str(resultado[0][3])
	estoque = int(resultado[0][4])

	PROCURAPRODUTO.T1.setText(nome)
	PROCURAPRODUTO.T2.setText(IDproduto)
	PROCURAPRODUTO.T3.setText(cat)
	PROCURAPRODUTO.T4.setText(desc)
	PROCURAPRODUTO.T5.setText(preco)

	if estoque == 0:
		PROCURAPRODUTO.Le1.setText("Sem estoque!")
		IDproduto = None

def Mostra_Carrinho(): #Cliente: Visualiza PRODUTOS dentro do CARRINHO
	global IDlogado

	CARRINHO.Le1.setText("") 

	A = ("SELECT Nome_Pdt, Preco_Pdt, Qtd_Pdt FROM Produto NATURAL JOIN Carrega_Item NATURAL JOIN ClienteWEB WHERE ID_Cliente = %s;")
	B = (IDlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)

	CARRINHO.TW.setRowCount(size)
	CARRINHO.TW.setColumnCount(4)

	CARRINHO.TW.setColumnWidth(0,300)
	CARRINHO.TW.setColumnWidth(1,20)
	CARRINHO.TW.setColumnWidth(2,200)
	CARRINHO.TW.setColumnWidth(3,30)

	ValorCarrinho = 0.00

	for i in range (size):

		for j in range (3):
			CARRINHO.TW.setItem(i,j,QtWidgets.QTableWidgetItem(str(resultado[i][j])))
			CARRINHO.TW.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)

		TotalProduto = float(resultado[i][1]) * int(resultado[i][2])
		CARRINHO.TW.setItem(i,3,QtWidgets.QTableWidgetItem(str(TotalProduto)))
		CARRINHO.TW.item(i,3).setTextAlignment(Qt.Qt.AlignCenter)
		ValorCarrinho = ValorCarrinho + TotalProduto

	CARRINHO.T5.setText(str(ValorCarrinho))
	Frete = 15.90
	Total = ValorCarrinho + Frete
	CARRINHO.T7.setText(str(Total))

def Mostra_Cart_Cliente(): #Funcionario: visualiza PRODUTOS dentro do CARRINHO
	COMPRAASSISTIDA.Le1.setText("")
	IDcart = COMPRAASSISTIDA.L2S.text()
	if IDcart == "":
		return

	A = ("SELECT Nome_Pdt, Qtd_Pdt, Preco_Pdt FROM Produto NATURAL JOIN Carrega_Item WHERE ID_Cart = %s;")
	B = (IDcart,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)

	COMPRAASSISTIDA.TW_2.setRowCount(size)
	COMPRAASSISTIDA.TW_2.setColumnCount(3)

	COMPRAASSISTIDA.TW_2.setColumnWidth(0,180)
	COMPRAASSISTIDA.TW_2.setColumnWidth(1,60)
	COMPRAASSISTIDA.TW_2.setColumnWidth(2,20)
	

	ValorCarrinho = 0.00

	for i in range (size):

		for j in range (2):
			COMPRAASSISTIDA.TW_2.setItem(i,j,QtWidgets.QTableWidgetItem(str(resultado[i][j])))
			COMPRAASSISTIDA.TW_2.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)

		TotalProduto = float(resultado[i][2]) * int(resultado[i][1])
		COMPRAASSISTIDA.TW_2.setItem(i,2,QtWidgets.QTableWidgetItem(str(TotalProduto)))
		COMPRAASSISTIDA.TW_2.item(i,2).setTextAlignment(Qt.Qt.AlignCenter)
		ValorCarrinho = ValorCarrinho + TotalProduto

	COMPRAASSISTIDA.L3S.setText(str(ValorCarrinho))

def Visualiza_Produtos(): #Cliente: Visualiza PRODUTOS dentro do PEDIDO
	
	linha = MEUSPEDIDOS.TW1.currentRow()
	if linha == -1:
		return
	IDpedido = MEUSPEDIDOS.TW1.item(linha, 0).text()

	A = "SELECT Nome_Pdt, count(ID_Item), Preco_Pdt FROM Itens NATURAL JOIN Produto WHERE ID_Pdd = %s GROUP BY ID_Pdt;"
	B = (IDpedido,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)

	MEUSPEDIDOS.TW1_2.setRowCount(size)
	MEUSPEDIDOS.TW1_2.setColumnCount(3)

	for i in range (size):
		for j in range (3):
			MEUSPEDIDOS.TW1_2.setItem(i,j,QtWidgets.QTableWidgetItem(str(resultado[i][j])))
			MEUSPEDIDOS.TW1_2.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)
	
def Mostra_Pedidos(): #Cliente: Visualiza PEDIDOS
	global IDlogado

	A = ("SELECT ID_Pdd, Status_Pdd, Valor_Pdd, Data_Pdd FROM Conta NATURAL JOIN Pedidos WHERE ID_Cliente = %s;")
	B = (IDlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)

	MEUSPEDIDOS.TW1.setRowCount(size)
	MEUSPEDIDOS.TW1.setColumnCount(4)

	MEUSPEDIDOS.TW1.setColumnWidth(0,60)
	MEUSPEDIDOS.TW1.setColumnWidth(1,300)
	MEUSPEDIDOS.TW1.setColumnWidth(2,60)
	MEUSPEDIDOS.TW1.setColumnWidth(3,60)

	MEUSPEDIDOS.TW1_2.setColumnWidth(0,200)
	MEUSPEDIDOS.TW1_2.setColumnWidth(1,20)
	MEUSPEDIDOS.TW1_2.setColumnWidth(2,20)

	for i in range (size):
		DATANDO = str(resultado[i][3])
		DATA = "{}/{}/{}".format(DATANDO[8:10],DATANDO[5:7], DATANDO[0:4])
		MEUSPEDIDOS.TW1.setItem(i,3,QtWidgets.QTableWidgetItem(DATA))
		MEUSPEDIDOS.TW1.item(i,3).setTextAlignment(Qt.Qt.AlignCenter)
		for j in range (3):
			MEUSPEDIDOS.TW1.setItem(i,j,QtWidgets.QTableWidgetItem(str(resultado[i][j])))
			MEUSPEDIDOS.TW1.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)

def Mostra_Clientes(): #Funcionario: Visualiza CLIENTES
	global Pesquisa
	
	email = ""
	estado = BUSCACLIENTE.L2_1.text()
	cidade = BUSCACLIENTE.L2_2.text()
	bairro = BUSCACLIENTE.L2_3.text()

	if BUSCACLIENTE.C1.isChecked():
		if BUSCACLIENTE.C2.isChecked():
			ano = BUSCACLIENTE.L1.text()
			A = "SELECT ID_Cliente, Nome_P, Telefone_P, Estado_P, Cidade_P, Bairro_P, Email_P from Pessoa NATURAL JOIN Cliente NATURAL JOIN Conta NATURAL JOIN (SELECT ID_Conta, count(Mes) as QTD FROM (SELECT DISTINCT ID_Conta, month(Data_Pdd) as Mes FROM Pedidos WHERE Status_Pdd = 'Finalizado' and year(Data_Pdd) = {}) as T1 GROUP BY ID_Conta HAVING QTD = 12) as T2;".format(ano)
		else:
			A = "SELECT ID_Cliente, Nome_P, Telefone_P, Estado_P, Cidade_P, Bairro_P, Email_P from Pessoa JOIN Cliente ON Pessoa.CPF_P = Cliente.CPF_P WHERE Email_P LIKE '%@%' and Estado_P LIKE '%{}%' and Cidade_P LIKE '%{}%' and Bairro_P LIKE '%{}%';".format(estado, cidade, bairro)
	else:
		A = "SELECT ID_Cliente, Nome_P, Telefone_P, Estado_P, Cidade_P, Bairro_P, Email_P from Pessoa JOIN Cliente ON Pessoa.CPF_P = Cliente.CPF_P WHERE Estado_P LIKE '%{}%' and Cidade_P LIKE '%{}%' and Bairro_P LIKE '%{}%';".format(estado, cidade, bairro)
	cursor.execute(A)
	Resultado = cursor.fetchall()
	size = len(Resultado)

	BUSCACLIENTE.L1_2.setText(str(size))
	
	BUSCACLIENTE.TW.setRowCount(size)
	BUSCACLIENTE.TW.setColumnCount(7)

	BUSCACLIENTE.TW.setColumnWidth(0,30)
	BUSCACLIENTE.TW.setColumnWidth(1,200)
	BUSCACLIENTE.TW.setColumnWidth(2,40)
	BUSCACLIENTE.TW.setColumnWidth(3,30)
	BUSCACLIENTE.TW.setColumnWidth(4,40)
	BUSCACLIENTE.TW.setColumnWidth(5,30)
	BUSCACLIENTE.TW.setColumnWidth(6,40)

	for i in range (size):
		for j in range (7):
			BUSCACLIENTE.TW.setItem(i,j,QtWidgets.QTableWidgetItem(str(Resultado[i][j])))
			BUSCACLIENTE.TW.item(i,j).setTextAlignment(Qt.Qt.AlignCenter)
		
#-------------[Comprar]-----------------
def Adiciona_Carrinho(): #Cliente: Tenta colocar o o produto no carrinho
	global IDproduto
	global IDlogado
	
	Visualiza_Produto()

	if IDproduto == None:
		return 1
	else:
		flag = Verifica_Estoque(IDproduto, 1)
		if flag == 1:
			PROCURAPRODUTO.Le1.setText("Sem estoque!")
			return 1
		A = "SELECT ID_Cart FROM Carrinho natural join Conta WHERE ID_Cliente = %s;" 
		B = (IDlogado,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		IDcart = resultado[0][0]

		flag = Verifica_Produto_Carrinho(IDproduto, IDcart)
		if flag == 1:
			PROCURAPRODUTO.Le1.setText("Já adicionado!")
			return 0

		Coloca_Carrinho(IDproduto, IDcart)
		PROCURAPRODUTO.Le1.setText("")
		tela_operacaorealizada()
		return 0

def Enviar_Carrinho(): #Funcionario: Coloca Produto no Carrinho
	linha = COMPRAASSISTIDA.TW.currentRow()
	if linha == -1:
		return
	IDproduto = COMPRAASSISTIDA.TW.item(linha, 0).text()

	flag = Verifica_Estoque(IDproduto, 1)

	if flag == 1:
		COMPRAASSISTIDA.Le1.setText("Sem estoque!")
		return

	cpf = COMPRAASSISTIDA.L1.text()
	A = "SELECT ID_Cart FROM Carrinho natural join Cliente natural join Conta WHERE CPF_P = %s;" 
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0:
		COMPRAASSISTIDA.Le1.setText("Cliente Inválido")
		return

	IDcart = resultado[0][0]

	COMPRAASSISTIDA.L2S.setText(str(IDcart)) #LabelSecreta

	Mostra_Cart_Cliente()

	flag = Verifica_Produto_Carrinho(IDproduto, IDcart)
	if flag == 1:
		COMPRAASSISTIDA.Le1.setText("Já adicionado!")
		return
	Coloca_Carrinho(IDproduto, IDcart)
	PROCURAPRODUTO.Le1.setText("")
	Mostra_Cart_Cliente()
	return

def Comprar(): #Cliente: Tenta comprar produto
	flag = Adiciona_Carrinho()
	if flag == 0:
		Visualiza_Carrinho()
	return

def Alterar_Quantidade(): #Cliente: Altera a quantidade de um produto no carrinho
	global IDlogado

	linha = CARRINHO.TW.currentRow()
	if linha == -1:
		return
	nome = CARRINHO.TW.item(linha, 0).text()
	A = "SELECT ID_Pdt FROM Produto WHERE Nome_Pdt = %s;"
	B = (nome,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDproduto = resultado[0][0]

	qtd = CARRINHO.spinBox.value()

	A = "SELECT ID_Cart FROM ClienteWEB WHERE ID_Cliente = %s;"
	B = (IDlogado,)
	cursor.execute(A,B)   
	resultado = cursor.fetchall()
	IDcart = resultado[0][0]

	if qtd == 0:
		CARRINHO.Le1.setText("Removido")
		Tirar_Carrinho(IDcart, IDproduto)
		
	else:
		flag = Verifica_Estoque(IDproduto, qtd)
		if flag == 1:
			CARRINHO.Le1.setText("Sem estoque")
			return
		Altera_qtd_Produto(IDproduto, IDcart, qtd)

	Visualiza_Carrinho()

def Mexer_Carrinho_Cli(): #Funcionario: Altera qtd de produto no carrinho
	IDcart = COMPRAASSISTIDA.L2S.text()

	linha = COMPRAASSISTIDA.TW_2.currentRow()
	if linha == -1:
		return
	nome = COMPRAASSISTIDA.TW_2.item(linha, 0).text()
	linha = COMPRAASSISTIDA.TW_2.currentRow()
	if linha == -1:
		return
	nome = COMPRAASSISTIDA.TW_2.item(linha, 0).text()
	A = "SELECT ID_Pdt FROM Produto WHERE Nome_Pdt = %s;"
	B = (nome,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDproduto = resultado[0][0]

	qtd = COMPRAASSISTIDA.spinBox.value()

	if qtd == 0:
		COMPRAASSISTIDA.Le1.setText("Removido")
		Tirar_Carrinho(IDcart, IDproduto)
		
	else:
		flag = Verifica_Estoque(IDproduto, qtd)
		if flag == 1:
			COMPRAASSISTIDA.Le1.setText("Sem estoque")
			return
		Altera_qtd_Produto(IDproduto, IDcart, qtd)
	Mostra_Cart_Cliente() 

def Remover_Produto(): #Cliente: Remove um produto do carrinho
	global IDlogado

	linha = CARRINHO.TW.currentRow()
	if linha == -1:
		return
	nome = CARRINHO.TW.item(linha, 0).text()
	A = "SELECT ID_Pdt FROM Produto WHERE Nome_Pdt = %s;"
	B = (nome,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDproduto = resultado[0][0]

	CARRINHO.Le1.setText("Removido")
	A = "SELECT ID_Cart FROM ClienteWEB WHERE ID_Cliente = %s;"
	B = (IDlogado,)
	cursor.execute(A,B)   
	resultado = cursor.fetchall()
	IDcart = resultado[0][0]
	Tirar_Carrinho(IDcart, IDproduto)
	Visualiza_Carrinho()

def Tirar_Produto():#Funcionário: Remove um produto do carrinho
	IDcart = COMPRAASSISTIDA.L2S.text()

	linha = COMPRAASSISTIDA.TW_2.currentRow()
	if linha == -1:
		return
	nome = COMPRAASSISTIDA.TW_2.item(linha, 0).text()
	linha = COMPRAASSISTIDA.TW_2.currentRow()
	if linha == -1:
		return
	nome = COMPRAASSISTIDA.TW_2.item(linha, 0).text()
	A = "SELECT ID_Pdt FROM Produto WHERE Nome_Pdt = %s;"
	B = (nome,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDproduto = resultado[0][0]

	Tirar_Carrinho(IDcart, IDproduto)
	Mostra_Cart_Cliente()

def Finalizar_Compra(): #Cliente: Finaliza a compra e faz o pedido
	global IDlogado

	Forma = None

	if FINALIZACOMPRA.F1.isChecked():
		Forma = "Cartão"	
	if FINALIZACOMPRA.F2.isChecked():
		Forma = "Boleto"	
	if FINALIZACOMPRA.F3.isChecked():
		Forma = "Pix"	

	if Forma == None:
		FINALIZACOMPRA.Le1.setText("Insira Pagamento!")
		return

	A = "SELECT ID_Cart FROM ClienteWEB WHERE ID_Cliente = %s"
	B = (IDlogado,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDcart = resultado[0][0]

	Valor = Fazer_Pedido(IDcart, IDlogado)

	
	tela_procuraproduto()
	tela_operacaorealizada()

def Finaliza_Compra_Pelo(): #Funcionario Finaliza compra pelo cliente
	global IDlogado
	IDcart = COMPRAASSISTIDA.L2S.text()

	A = "SELECT ID_Cliente FROM Conta NATURAL JOIN Carrinho WHERE ID_Cart = %s;"
	B = (IDcart,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	IDcliente = resultado[0][0]

	Valor = Fazer_Pedido(IDcart, IDcliente)
	Relatorio_Cliente(IDlogado, IDcliente, "Compra")

	tela_homefuncionario()
	tela_operacaorealizada()

#-------------[UTILIDADE]---------------
def Mudar_Dados(): #Cliente: Muda seus dados
	global CPFlogado
	global IDlogado

	MUDADADOS.Le1.setText("")
	MUDADADOS.Le3.setText("")
	MUDADADOS.Le4.setText("")
	MUDADADOS.Le5.setText("")
	MUDADADOS.Le6.setText("")
	MUDADADOS.Le7.setText("")


	nome = MUDADADOS.LN1.text()
	tel = MUDADADOS.LN4.text()
	estado = MUDADADOS.LN5.text()
	cidade = MUDADADOS.LN6.text()
	bairro = MUDADADOS.LN7.text()
	end = MUDADADOS.LN8.text()
	email = MUDADADOS.LN9.text()
	senha = MUDADADOS.LN9_2.text()

	flag = 0

	#---------Não permite alteração:
	if nome == "":
	    MUDADADOS.Le1.setText("*")
	    flag = 1
	    
	if estado == "":
	    MUDADADOS.Le3.setText("*")
	    flag = 1
	
	if cidade == "":
	    MUDADADOS.Le4.setText("*")
	    flag = 1

	if bairro == "":
	    MUDADADOS.Le5.setText("*")
	    flag = 1

	if end == "":
	    MUDADADOS.Le6.setText("*")
	    flag = 1

	if email == "":
	    MUDADADOS.Le7.setText("*")
	    flag = 1
	else:
		A = "SELECT CPF_P from Pessoa where Email_P = %s"
		B = (email,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		size = len(resultado)
		if size > 0:
			if resultado[0][0] != CPFlogado:
				MUDADADOS.Le4_2.setText("Email já cadastrado")
				return			

	if senha == "":
	    MUDADADOS.Le8.setText("*")
	    flag = 1

	if tel == "":
	    MUDADADOS.Le2.setText("*")
	    flag = 1
	else:
		A = "SELECT CPF_P from Pessoa where Telefone_P = %s"
		B = (tel,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		size = len(resultado)
		if size > 0:
			if resultado[0][0] != CPFlogado:
				MUDADADOS.Le4_2.setText("Telefone já cadastrado")
				return

	if flag == 1:
		return

	A = "UPDATE Pessoa SET Nome_P = %s, Telefone_P = %s, Estado_P = %s, Bairro_P = %s, Cidade_P = %s, Endereco_P = %s, Email_P = %s where CPF_P = %s;"
	B = (nome, tel, estado, bairro, cidade, end, email, CPFlogado)
	cursor.execute(A,B)
	A = "UPDATE ClienteWEB SET Senha_WEB = %s where User_WEB = %s;"
	B = (senha, email)
	cursor.execute(A,B)

	#-------Salvar no BD:
	BD.commit()

	tela_minhaconta()
	return 

def Muda_FuncDados(): #Funcionario: Muda seus dados
	global CPFlogado
	global IDlogado

	MUDAFUNCDADOS.Le1.setText("")
	MUDAFUNCDADOS.Le3.setText("")
	MUDAFUNCDADOS.Le4.setText("")
	MUDAFUNCDADOS.Le5.setText("")
	MUDAFUNCDADOS.Le6.setText("")
	
	nome = MUDAFUNCDADOS.LN1.text()
	tel = MUDAFUNCDADOS.LN4.text()
	estado = MUDAFUNCDADOS.LN5.text()
	cidade = MUDAFUNCDADOS.LN6.text()
	bairro = MUDAFUNCDADOS.LN7.text()
	end = MUDAFUNCDADOS.LN8.text()
	senha = MUDAFUNCDADOS.LN9_2.text()

	flag = 0

	#---------Não permite alteração:
	if nome == "":
	    MUDAFUNCDADOS.Le1.setText("*")
	    flag = 1
	    
	if estado == "":
	    MUDAFUNCDADOS.Le3.setText("*")
	    flag = 1
	
	if cidade == "":
	    MUDAFUNCDADOS.Le4.setText("*")
	    flag = 1

	if bairro == "":
	    MUDAFUNCDADOS.Le5.setText("*")
	    flag = 1

	if end == "":
	    MUDAFUNCDADOS.Le6.setText("*")
	    flag = 1

	if senha == "":
	    MUDAFUNCDADOS.Le8.setText("*")
	    flag = 1

	if tel == "":
	    MUDAFUNCDADOS.Le2.setText("*")
	    flag = 1
	else:
		A = "SELECT CPF_P from Pessoa where Telefone_P = %s"
		B = (tel,)
		cursor.execute(A,B)
		resultado = cursor.fetchall()
		size = len(resultado)
		if size > 0:
			if resultado[0][0] != CPFlogado:
				MUDAFUNCDADOS.Le4_2.setText("Telefone já cadastrado")
				return

	if flag == 1:
		return

	A = "UPDATE Pessoa SET Nome_P = %s, Telefone_P = %s, Estado_P = %s, Bairro_P = %s, Cidade_P = %s, Endereco_P = %s where CPF_P = %s;"
	B = (nome, tel, estado, bairro, cidade, end, CPFlogado)
	cursor.execute(A,B)
	A = "UPDATE Funcionario SET Senha_Func = %s where CPF_P = %s;"
	B = (senha, CPFlogado)
	cursor.execute(A,B)

	#-------Salvar no BD:
	BD.commit()
	tela_minhafuncconta()
	tela_operacaorealizada()

def Muda_Dados_Cliente():
	nome = DADOSCLIENTE.LN1.text()
	cpf = DADOSCLIENTE.LN3.text()
	telefone = DADOSCLIENTE.LN4.text()
	estado = DADOSCLIENTE.LN5.text()
	cidade = DADOSCLIENTE.LN6.text()
	bairro = DADOSCLIENTE.LN7.text()
	end = DADOSCLIENTE.LN8.text()
	email = DADOSCLIENTE.LN9.text()

	A = "UPDATE Pessoa SET Nome_P = %s, Telefone_P = %s, Estado_P = %s, Cidade_P = %s, Bairro_P = %s, Endereco_P = %s, Email_P = %s WHERE CPF_P = %s;"
	B = (nome, telefone, estado, cidade, bairro, end, email, cpf)
	cursor.execute(A,B)
	BD.commit()
	tela_homefuncionario()
	tela_operacaorealizada() #Funcionario: muda dados do cliente

def FUNC_Atualiza_Pedido():
	global IDlogado
	IDpedido = ATUALIZAPEDIDO.L1.text()
	status = ATUALIZAPEDIDO.L3.text()

	Status_Pedido(IDpedido, status)
	Relatorio_Pedido(IDlogado, IDpedido, status)
	tela_homefuncionario()
	tela_operacaorealizada() #Funcionario: atualiza pedido

def fecha_operacao():
	OPERACAOREALIZADA.close()
	ERROOPERACAO.close()
	DESEJASAIR.close()
	CERTEZA.close() #Fecha confirmações

def Atualiza_Status():
	global IDlogado
	
	linha = BUSCACLIENTE.TW.currentRow()
	IDcliente = BUSCACLIENTE.TW.item(linha, 0).text()

	if GERENCIAUSUARIO.C1.isChecked():
		Atualizar_Usuario(IDcliente, "Ativo")
		Relatorio_Cliente(IDlogado, IDcliente, "Ativo")

		
	if GERENCIAUSUARIO.C2.isChecked():
		Atualizar_Usuario(IDcliente, "Bloqueado")
		Relatorio_Cliente(IDlogado, IDcliente, "Bloqueado")
		
	if GERENCIAUSUARIO.C3.isChecked():
		Atualizar_Usuario(IDcliente, "Desativado")
		Relatorio_Cliente(IDlogado, IDcliente, "Desativado")
		
	tela_buscacliente()
	tela_operacaorealizada() #Atualiza Status do Usuario #Funcionario: muda status do usuario do cliente

def CPF_Nome():
	cpf = COMPRAASSISTIDA.L1.text()
	if cpf == "":		
		return
	A = "SELECT Nome_P, ID_Cart FROM Pessoa NATURAL JOIN Cliente NATURAL JOIN Conta NATURAL JOIN Carrinho WHERE CPF_P = %s;"
	B = (cpf,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size > 0:
		nome = resultado[0][0]
		IDcart = resultado[0][1]
		COMPRAASSISTIDA.L2S.setText(str(IDcart))
		COMPRAASSISTIDA.L1_2.setText(nome)
		COMPRAASSISTIDAFINALIZA.L1.setText(str(IDcart))
		COMPRAASSISTIDAFINALIZA.L1_2.setText(nome)
		Mostra_Cart_Cliente()
	else:
		COMPRAASSISTIDA.Le1.setText("Cliente Inválido!") #Funcionario acha o nome pelo CPF

def IDproduto_Nome():
	ESTOCARPRODUTO.L3.setText("")
	ESTOCARPRODUTO.L4.setText("")
	IDproduto = ESTOCARPRODUTO.L1.text()
	if IDproduto == "":
		return
	A = "SELECT Nome_Pdt FROM Produto WHERE ID_Pdt = %s;"
	B = (IDproduto,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0:
		return
	nome = resultado[0][0]

	ESTOCARPRODUTO.L2.setText(nome) #Funcionario acha produto pelo nome

def IDpedido_Status():
	IDpedido = ATUALIZAPEDIDO.L1.text()
	
	A = "SELECT Status_Pdd FROM Pedidos WHERE ID_Pdd = %s;"
	B = (IDpedido,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	size = len(resultado)
	if size == 0:
		ATUALIZAPEDIDO.Le1.setText("Pedido Inválido")
		return
	status = resultado[0][0]

	ATUALIZAPEDIDO.L2.setText(status)# #Funcionario acha Statos do produto pelo nome

def Atribuir_Pagamento():
	IDpedido = INSERIRPAGAMENTO.L1.text()
	Valor = INSERIRPAGAMENTO.L3.value()
	if INSERIRPAGAMENTO.C1.isChecked():
		Tipo = "Cartão"
	if INSERIRPAGAMENTO.C1_2.isChecked():
		Tipo = "Boleto"
	if INSERIRPAGAMENTO.C1_3.isChecked():
		Tipo = "Pix"

	Inserir_Pagamento(IDpedido, Tipo, Valor)

	A = "SELECT sum(Valor_Pgmt) FROM Pagamentos WHERE ID_Pdd = %s;"
	B = (IDpedido,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	ValorPago = resultado[0][0]

	A = "SELECT Valor_Pdd FROM Pedidos WHERE ID_Pdd = %s;"
	B = (IDpedido,)
	cursor.execute(A,B)
	resultado = cursor.fetchall()
	ValorPedido = resultado[0][0]

	if ValorPago >= ValorPedido:
		Status_Pedido(IDpedido, "Finalizado")

	tela_operacaorealizada() #Funcionario insere pagamento

#-===================================================== TELAS UNIVERSAIS ============
HOME = uic.loadUi("Windows/Home.ui")
HOME.B1.clicked.connect(tela_login)
#---------------------------------------
LOGIN = uic.loadUi("Windows/Login.ui")
LOGIN.B1.clicked.connect(Login) #ACTION: Entrar
LOGIN.B2.clicked.connect(tela_cadcliente) #Cadastro
LOGIN.B3.clicked.connect(tela_home) #Voltar
#---------------------------------------
DESEJASAIR = uic.loadUi("Windows/DesejaMesmoSair.ui")
DESEJASAIR.B1.clicked.connect(Logout) #SIM
DESEJASAIR.B2.clicked.connect(fecha_operacao) #NÃO
#---------------------------------------
CERTEZA = uic.loadUi("Windows/VoceTemCerteza.ui")
CERTEZA.B1.clicked.connect(Excluir_MinhaConta) #SIM
CERTEZA.B2.clicked.connect(fecha_operacao) #NÃO
#---------------------------------------
USUARIOBLOQUEADO = uic.loadUi("Windows/UsuarioBloqueado.ui")
USUARIOBLOQUEADO.B1.clicked.connect(tela_login) #Continuhar
#---------------------------------------
OPERACAOREALIZADA = uic.loadUi("Windows/OperacaoRealizada.ui")
OPERACAOREALIZADA.B1.clicked.connect(fecha_operacao)
#---------------------------------------
ERROOPERACAO = uic.loadUi("Windows/ErroOperacao.ui")
ERROOPERACAO.B1.clicked.connect(fecha_operacao)

#-========================================================== CLIENTE ================
CADCLIENTE = uic.loadUi("Windows/CadastroCliente.ui")
CADCLIENTE.B1.clicked.connect(Criar_Cliente) #ACTION: Cadastrar Cliente
CADCLIENTE.B2.clicked.connect(tela_cadusuario) #Criar Usuário
CADCLIENTE.B3.clicked.connect(tela_login) #voltar
#---------------------------------------
CADUSUARIO = uic.loadUi("Windows/CriarUsuario.ui")
CADUSUARIO.B1.clicked.connect(Criar_Usuario) #ACTION:Criar Usuário
CADUSUARIO.B2.clicked.connect(tela_cadcliente) #voltar
#---------------------------------------
PROCURAPRODUTO = uic.loadUi("Windows/ClienteProcuraProduto.ui")
PROCURAPRODUTO.B1.clicked.connect(tela_minhaconta)#Minha Conta
PROCURAPRODUTO.B2.clicked.connect(tela_desejasair)#Sair
PROCURAPRODUTO.B3.clicked.connect(Visualiza_Carrinho)#ACTION:Carrinho
PROCURAPRODUTO.B4.clicked.connect(tela_procuraproduto)#Lupa de Pesquisa
PROCURAPRODUTO.B5.clicked.connect(Mostra_Produtos)#ACTION:FiltrarCat
PROCURAPRODUTO.B7.clicked.connect(Visualiza_Produto)#ACTION:Visualizar
PROCURAPRODUTO.B8.clicked.connect(Comprar)#ACTION:Comprar
PROCURAPRODUTO.B9.clicked.connect(Adiciona_Carrinho)#ACTION: AddCarrinho
#---------------------------------------
MINHACONTA = uic.loadUi("Windows/MinhaConta.ui")
MINHACONTA.B2.clicked.connect(tela_desejasair)#Sair
MINHACONTA.B3.clicked.connect(Visualiza_Carrinho)#ACTION:Carrinho
MINHACONTA.B5.clicked.connect(tela_procuraproduto)#Voltar
MINHACONTA.B6.clicked.connect(tela_mudadados)#Alterar dados
MINHACONTA.B7.clicked.connect(tela_meuspedidos)#Meus Pedidos
MINHACONTA.B8.clicked.connect(tela_certeza)#ACTION:Excluir Conta
#---------------------------------------
MUDADADOS = uic.loadUi("Windows/MudaDados.ui")
MUDADADOS.B2.clicked.connect(tela_desejasair)#Sair
MUDADADOS.B3.clicked.connect(Visualiza_Carrinho)#ACTION:Carrinho
MUDADADOS.B5.clicked.connect(tela_minhaconta)#Voltar
MUDADADOS.B6.clicked.connect(Mudar_Dados)#Salvar Dados
#---------------------------------------
CARRINHOVAZIO = uic.loadUi("Windows/CarrinhoVazio.ui")
CARRINHOVAZIO.B1.clicked.connect(tela_minhaconta)#Minha Conta
CARRINHOVAZIO.B2.clicked.connect(tela_desejasair)#Sair
CARRINHOVAZIO.B5.clicked.connect(tela_procuraproduto)#Voltar
#---------------------------------------
CARRINHO = uic.loadUi("Windows/Carrinho.ui")
CARRINHO.B1.clicked.connect(tela_minhaconta)#Minha Conta
CARRINHO.B2.clicked.connect(tela_desejasair)#Sair
CARRINHO.B5.clicked.connect(tela_procuraproduto)#Voltar
CARRINHO.B6.clicked.connect(Alterar_Quantidade)#Alterar Item
CARRINHO.B7.clicked.connect(Remover_Produto)#Remover
CARRINHO.B8.clicked.connect(tela_finalizacompra)#FinalizaCompra
#---------------------------------------
FINALIZACOMPRA = uic.loadUi("Windows/FinalizaCompra.ui")
FINALIZACOMPRA.B1.clicked.connect(Visualiza_Carrinho)#ACTION:Carrinho
FINALIZACOMPRA.B2.clicked.connect(tela_mudadados)#Alterar dados
FINALIZACOMPRA.B3.clicked.connect(Finalizar_Compra)#FinalizarCompra
#---------------------------------------
MEUSPEDIDOS = uic.loadUi("Windows/MeusPedidos.ui")
MEUSPEDIDOS.B1.clicked.connect(tela_minhaconta)#Minha Conta
MEUSPEDIDOS.B2.clicked.connect(tela_desejasair)#Sair
MEUSPEDIDOS.B3.clicked.connect(Visualiza_Carrinho)#ACTION:Carrinho
MEUSPEDIDOS.B5.clicked.connect(tela_procuraproduto)#Voltar
MEUSPEDIDOS.B6.clicked.connect(Visualiza_Produtos)#Ver pedido

#-=========================================================== FUNCIONARIO ===============
HOMEFUNCIONARIO = uic.loadUi("Windows/HomeFuncionario.ui")
HOMEFUNCIONARIO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
HOMEFUNCIONARIO.B2.clicked.connect(tela_desejasair)#Sair
HOMEFUNCIONARIO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
HOMEFUNCIONARIO.B4_2.clicked.connect(tela_buscacliente)#CLIENTE: Buscar
HOMEFUNCIONARIO.B4_3.clicked.connect(tela_compraassistida)#CLIENTE: Comprar
HOMEFUNCIONARIO.B5_1.clicked.connect(tela_cadastrarproduto)#PRODUTO: Cadastrar
HOMEFUNCIONARIO.B5_3.clicked.connect(tela_estocarproduto)#PRODUTO: Atualizar Estoque
HOMEFUNCIONARIO.B6_1.clicked.connect(tela_buscapedido)#PEDIDOS: Buscar
HOMEFUNCIONARIO.B6_2.clicked.connect(tela_atualizastatus)#PEDIDOS: Atualizar Status
HOMEFUNCIONARIO.B7_1.clicked.connect(tela_inserirpagamento)#FINANCR: Inserir Pagamento
HOMEFUNCIONARIO.B7_3.clicked.connect(tela_vendas)#FINANCR: Vendas Nas Lojas
HOMEFUNCIONARIO.B8.clicked.connect(tela_adm)#ADM
#---------------------------------------
ADM = uic.loadUi("Windows/Adm.ui")
ADM.B1.clicked.connect(tela_cadastrofuncionario)#Cadastrar Funcionario
ADM.B2.clicked.connect(tela_cadastrofuncli)#Cadastrar Cliente
ADM.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
ADM.B5_1.clicked.connect(tela_listafuncionarios)#Buscar Funcionarios
ADM.B5_2.clicked.connect(Exc_Func)#Excluir Funcionario
ADM.B6_1.clicked.connect(tela_buscacliente)#Buscar Cliente
ADM.B6_2.clicked.connect(Exc_Cli)#Excluir Cliente
ADM.B7.clicked.connect(Exc_Tudo)#Excluir Pessoa
#---------------------------------------
MINHAFUNCCONTA = uic.loadUi("Windows/MinhaFuncConta.ui")
MINHAFUNCCONTA.B2.clicked.connect(tela_desejasair)#Sair
MINHAFUNCCONTA.B3.clicked.connect(tela_homefuncionario)#-----------------MinhaAtividade
MINHAFUNCCONTA.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
MINHAFUNCCONTA.B5.clicked.connect(tela_mudafuncdados)#Alterar Dados
MINHAFUNCCONTA.B6.clicked.connect(tela_homefuncionario)#-----------------Meus Serviços
#---------------------------------------
MUDAFUNCDADOS = uic.loadUi("Windows/MudaFuncDados.ui")
MUDAFUNCDADOS.B2.clicked.connect(tela_desejasair)#Sair
MUDAFUNCDADOS.B3.clicked.connect(tela_homefuncionario)#------------------MinhaAtividade
MUDAFUNCDADOS.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
MUDAFUNCDADOS.B5.clicked.connect(Muda_FuncDados)#ACTION:Salvar Dados
#---------------------------------------
CADASTROFUNCLI = uic.loadUi("Windows/CadastroFunCli.ui")
CADASTROFUNCLI.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
CADASTROFUNCLI.B2.clicked.connect(tela_desejasair)#Sair
CADASTROFUNCLI.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
CADASTROFUNCLI.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
CADASTROFUNCLI.B5.clicked.connect(Func_CriaCliente)#ACTION:Criar cliente
#---------------------------------------
BUSCACLIENTE = uic.loadUi("Windows/BuscaCliente.ui")
BUSCACLIENTE.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
BUSCACLIENTE.B2.clicked.connect(tela_desejasair)#Sair
BUSCACLIENTE.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
BUSCACLIENTE.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
BUSCACLIENTE.B5.clicked.connect(Mostra_Clientes)#Filtra Clientes
BUSCACLIENTE.B6.clicked.connect(tela_dadoscliente)#Dados Cliente
#--------------------------------------
DADOSCLIENTE = uic.loadUi("Windows/FuncMudaDadosCli.ui")
DADOSCLIENTE.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
DADOSCLIENTE.B2.clicked.connect(tela_desejasair)#Sair
DADOSCLIENTE.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
DADOSCLIENTE.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
DADOSCLIENTE.B5.clicked.connect(tela_gerenciausuario)#Gerencia usuario
DADOSCLIENTE.B6.clicked.connect(Muda_Dados_Cliente)#muda dados do cliente
#--------------------------------------
GERENCIAUSUARIO = uic.loadUi("Windows/GerenciaUsuario.ui") 
GERENCIAUSUARIO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
GERENCIAUSUARIO.B2.clicked.connect(tela_desejasair)#Sair
GERENCIAUSUARIO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
GERENCIAUSUARIO.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
GERENCIAUSUARIO.B5.clicked.connect(Atualiza_Status)#Atualizar Status
#--------------------------------------
COMPRAASSISTIDA = uic.loadUi("Windows/CompraAssistida.ui") 
COMPRAASSISTIDA.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
COMPRAASSISTIDA.B2.clicked.connect(tela_desejasair)#Sair
COMPRAASSISTIDA.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
COMPRAASSISTIDA.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
COMPRAASSISTIDA.B5.clicked.connect(CPF_Nome)#Confirmar CPF
COMPRAASSISTIDA.B0.clicked.connect(Buscar_Produto)#Buscar Produto Pelo Nome
COMPRAASSISTIDA.B6.clicked.connect(Enviar_Carrinho)#Coloca no Carrinho do Cliente
COMPRAASSISTIDA.B7.clicked.connect(Mexer_Carrinho_Cli)#Altera qtd Item do carrinho
COMPRAASSISTIDA.B8.clicked.connect(Tirar_Produto)#Remove Produto do carrinho
COMPRAASSISTIDA.B9.clicked.connect(tela_compraassistidafinaliza)#finalizacompra
#--------------------------------------
CADASTRARPRODUTO = uic.loadUi("Windows/CadastrarProduto.ui") 
CADASTRARPRODUTO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
CADASTRARPRODUTO.B2.clicked.connect(tela_desejasair)#Sair
CADASTRARPRODUTO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
CADASTRARPRODUTO.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
CADASTRARPRODUTO.B5.clicked.connect(Cadastrar_Produto)#CadastraProduto
#--------------------------------------
ESTOCARPRODUTO = uic.loadUi("Windows/EstocarProduto.ui") 
ESTOCARPRODUTO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
ESTOCARPRODUTO.B2.clicked.connect(tela_desejasair)#Sair
ESTOCARPRODUTO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
ESTOCARPRODUTO.B4.clicked.connect(tela_homefuncionario)#Voltar: Home
ESTOCARPRODUTO.B5.clicked.connect(Estocar_Produto)#EstocarProduto
ESTOCARPRODUTO.B5_2.clicked.connect(IDproduto_Nome)#Mostra Nome Produto
#--------------------------------------
COMPRAASSISTIDAFINALIZA = uic.loadUi("Windows/CompraAssistidaFinaliza.ui") 
COMPRAASSISTIDAFINALIZA.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
COMPRAASSISTIDAFINALIZA.B2.clicked.connect(tela_desejasair)#Sair
COMPRAASSISTIDAFINALIZA.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
COMPRAASSISTIDAFINALIZA.B4.clicked.connect(tela_compraassistida)#Voltar: Compra Assistida
COMPRAASSISTIDAFINALIZA.B5.clicked.connect(tela_buscacliente)#Alterar Dados Cliente/ buscar
COMPRAASSISTIDAFINALIZA.B6.clicked.connect(Finaliza_Compra_Pelo)#Finalizar Compra Pelo
#--------------------------------------
BUSCAPEDIDO = uic.loadUi("Windows/BuscaPedido.ui") 
BUSCAPEDIDO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
BUSCAPEDIDO.B2.clicked.connect(tela_desejasair)#Sair
BUSCAPEDIDO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
BUSCAPEDIDO.B4.clicked.connect(tela_homefuncionario)#Voltar 
BUSCAPEDIDO.B5.clicked.connect(tela_buscapedido)#Refresh
#--------------------------------------
ATUALIZAPEDIDO = uic.loadUi("Windows/AtualizaPedido.ui") 
ATUALIZAPEDIDO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
ATUALIZAPEDIDO.B2.clicked.connect(tela_desejasair)#Sair
ATUALIZAPEDIDO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
ATUALIZAPEDIDO.B4.clicked.connect(tela_homefuncionario)#Voltar 
ATUALIZAPEDIDO.B5_2.clicked.connect(IDpedido_Status)#Faz aparecer status do pedido
ATUALIZAPEDIDO.B5.clicked.connect(FUNC_Atualiza_Pedido)#Atualiza Pedido
#---------------------------------------
INSERIRPAGAMENTO = uic.loadUi("Windows/InserirPagamento.ui") 
INSERIRPAGAMENTO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
INSERIRPAGAMENTO.B2.clicked.connect(tela_desejasair)#Sair
INSERIRPAGAMENTO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
INSERIRPAGAMENTO.B4.clicked.connect(tela_homefuncionario)#Voltar 
INSERIRPAGAMENTO.B5.clicked.connect(Atribuir_Pagamento)#Inserir Pagamento
#---------------------------------------
CADASTROFUNCIONARIO = uic.loadUi("Windows/CadastroFuncionario.ui") 
CADASTROFUNCIONARIO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
CADASTROFUNCIONARIO.B2.clicked.connect(tela_desejasair)#Sair
CADASTROFUNCIONARIO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
CADASTROFUNCIONARIO.B4.clicked.connect(tela_adm)#Voltar 
CADASTROFUNCIONARIO.B5.clicked.connect(Cadastrar_Funcionario)#Cadastra Funcionario
#---------------------------------------
BUSCAFUNCIONARIO = uic.loadUi("Windows/BuscaFuncionario.ui") 
BUSCAFUNCIONARIO.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
BUSCAFUNCIONARIO.B2.clicked.connect(tela_desejasair)#Sair
BUSCAFUNCIONARIO.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
BUSCAFUNCIONARIO.B4.clicked.connect(tela_adm)#Voltar 
#---------------------------------------
VENDAS = uic.loadUi("Windows/Vendas.ui") 
VENDAS.B1.clicked.connect(tela_minhafuncconta)#Minha Conta
VENDAS.B2.clicked.connect(tela_desejasair)#Sair
VENDAS.B3.clicked.connect(tela_homefuncionario)#----------------------------MinhaAtividade
VENDAS.B4.clicked.connect(tela_homefuncionario)#Voltar 

#-============== RUN! ==================
tela_home()

APP.exec()