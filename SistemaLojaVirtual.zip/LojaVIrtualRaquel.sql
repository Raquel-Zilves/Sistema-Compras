-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: LojaRaquel
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AT_Produto`
--

DROP TABLE IF EXISTS `AT_Produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AT_Produto` (
  `ID_Func` int DEFAULT NULL,
  `ID_Pdt` int NOT NULL,
  `Valor_Pdt` double DEFAULT NULL,
  `Quantidade_Pdt` int DEFAULT NULL,
  `Data_At` date NOT NULL,
  KEY `ID_Func` (`ID_Func`),
  KEY `ID_Pdt` (`ID_Pdt`),
  CONSTRAINT `AT_Produto_ibfk_1` FOREIGN KEY (`ID_Func`) REFERENCES `Funcionario` (`ID_Func`) ON DELETE SET NULL,
  CONSTRAINT `AT_Produto_ibfk_2` FOREIGN KEY (`ID_Pdt`) REFERENCES `Produto` (`ID_Pdt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AT_Produto`
--

LOCK TABLES `AT_Produto` WRITE;
/*!40000 ALTER TABLE `AT_Produto` DISABLE KEYS */;
INSERT INTO `AT_Produto` VALUES (1,2,15,10,'2022-12-25'),(1,2,10.9,0,'2022-12-25'),(1,2,10.9,8,'2022-12-25');
/*!40000 ALTER TABLE `AT_Produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `At_Cliente`
--

DROP TABLE IF EXISTS `At_Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `At_Cliente` (
  `ID_Func` int DEFAULT NULL,
  `ID_Cliente` int DEFAULT NULL,
  `Acao` varchar(30) NOT NULL,
  `Data_At` date NOT NULL,
  KEY `ID_Func` (`ID_Func`),
  KEY `ID_Cliente` (`ID_Cliente`),
  CONSTRAINT `At_Cliente_ibfk_1` FOREIGN KEY (`ID_Func`) REFERENCES `Funcionario` (`ID_Func`) ON DELETE SET NULL,
  CONSTRAINT `At_Cliente_ibfk_2` FOREIGN KEY (`ID_Cliente`) REFERENCES `Cliente` (`ID_Cliente`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `At_Cliente`
--

LOCK TABLES `At_Cliente` WRITE;
/*!40000 ALTER TABLE `At_Cliente` DISABLE KEYS */;
INSERT INTO `At_Cliente` VALUES (1,NULL,'Compra','2022-12-25'),(1,NULL,'Bloqueado','2022-12-25'),(1,4,'Desativado','2022-12-25'),(1,4,'Ativo','2022-12-25'),(1,7,'Compra','2022-12-25');
/*!40000 ALTER TABLE `At_Cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `At_Pedido`
--

DROP TABLE IF EXISTS `At_Pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `At_Pedido` (
  `ID_Func` int DEFAULT NULL,
  `ID_Pdd` int NOT NULL,
  `Data` date NOT NULL,
  `Status` varchar(30) NOT NULL,
  KEY `ID_Func` (`ID_Func`),
  KEY `ID_Pdd` (`ID_Pdd`),
  CONSTRAINT `At_Pedido_ibfk_1` FOREIGN KEY (`ID_Func`) REFERENCES `Funcionario` (`ID_Func`) ON DELETE SET NULL,
  CONSTRAINT `At_Pedido_ibfk_2` FOREIGN KEY (`ID_Pdd`) REFERENCES `Pedidos` (`ID_Pdd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `At_Pedido`
--

LOCK TABLES `At_Pedido` WRITE;
/*!40000 ALTER TABLE `At_Pedido` DISABLE KEYS */;
INSERT INTO `At_Pedido` VALUES (1,3,'2022-12-25','Confirmado'),(1,1,'2022-12-25','Cancelado'),(1,3,'2022-12-25','Finalizado'),(1,5,'2022-12-25','Finalizado'),(1,6,'2022-12-25','Finalizado'),(1,7,'2022-12-25','Finalizado'),(1,2,'2022-12-25','Cancelado');
/*!40000 ALTER TABLE `At_Pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Carrega_Item`
--

DROP TABLE IF EXISTS `Carrega_Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Carrega_Item` (
  `ID_Pdt` int NOT NULL,
  `ID_Cart` int NOT NULL,
  `Qtd_Pdt` int NOT NULL,
  PRIMARY KEY (`ID_Pdt`,`ID_Cart`),
  KEY `ID_Cart` (`ID_Cart`),
  CONSTRAINT `Carrega_Item_ibfk_1` FOREIGN KEY (`ID_Pdt`) REFERENCES `Produto` (`ID_Pdt`),
  CONSTRAINT `Carrega_Item_ibfk_2` FOREIGN KEY (`ID_Cart`) REFERENCES `Carrinho` (`ID_Cart`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Carrega_Item`
--

LOCK TABLES `Carrega_Item` WRITE;
/*!40000 ALTER TABLE `Carrega_Item` DISABLE KEYS */;
/*!40000 ALTER TABLE `Carrega_Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Carrinho`
--

DROP TABLE IF EXISTS `Carrinho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Carrinho` (
  `ID_Cart` int NOT NULL AUTO_INCREMENT,
  `ID_Conta` int DEFAULT NULL,
  PRIMARY KEY (`ID_Cart`),
  KEY `ID_Conta` (`ID_Conta`),
  CONSTRAINT `Carrinho_ibfk_1` FOREIGN KEY (`ID_Conta`) REFERENCES `Conta` (`ID_Conta`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Carrinho`
--

LOCK TABLES `Carrinho` WRITE;
/*!40000 ALTER TABLE `Carrinho` DISABLE KEYS */;
INSERT INTO `Carrinho` VALUES (4,4),(5,5),(6,6),(7,7),(8,8);
/*!40000 ALTER TABLE `Carrinho` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cliente`
--

DROP TABLE IF EXISTS `Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Cliente` (
  `ID_Cliente` int NOT NULL AUTO_INCREMENT,
  `CPF_P` char(11) NOT NULL,
  PRIMARY KEY (`ID_Cliente`),
  KEY `CPF_P` (`CPF_P`),
  CONSTRAINT `Cliente_ibfk_1` FOREIGN KEY (`CPF_P`) REFERENCES `Pessoa` (`CPF_P`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cliente`
--

LOCK TABLES `Cliente` WRITE;
/*!40000 ALTER TABLE `Cliente` DISABLE KEYS */;
INSERT INTO `Cliente` VALUES (6,'11111111111'),(7,'22222222222'),(8,'44444444444'),(4,'93198621763'),(5,'99999999999');
/*!40000 ALTER TABLE `Cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClienteWEB`
--

DROP TABLE IF EXISTS `ClienteWEB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClienteWEB` (
  `User_WEB` varchar(60) NOT NULL,
  `Senha_WEB` varchar(30) NOT NULL,
  `Status_WEB` varchar(30) NOT NULL,
  `ID_Cliente` int NOT NULL,
  `ID_Cart` int NOT NULL,
  PRIMARY KEY (`User_WEB`),
  KEY `ID_Cliente` (`ID_Cliente`),
  KEY `ID_Cart` (`ID_Cart`),
  CONSTRAINT `ClienteWEB_ibfk_1` FOREIGN KEY (`User_WEB`) REFERENCES `Pessoa` (`Email_P`) ON DELETE CASCADE,
  CONSTRAINT `ClienteWEB_ibfk_2` FOREIGN KEY (`ID_Cliente`) REFERENCES `Cliente` (`ID_Cliente`) ON DELETE CASCADE,
  CONSTRAINT `ClienteWEB_ibfk_3` FOREIGN KEY (`ID_Cart`) REFERENCES `Carrinho` (`ID_Cart`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClienteWEB`
--

LOCK TABLES `ClienteWEB` WRITE;
/*!40000 ALTER TABLE `ClienteWEB` DISABLE KEYS */;
INSERT INTO `ClienteWEB` VALUES ('a@gmail.com','123','Novo',6,6),('g@gmail.com','123','Novo',7,7),('m@gmail.com','123','Ativo',5,5),('t@gmail.com','123','Ativo',4,4);
/*!40000 ALTER TABLE `ClienteWEB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Conta`
--

DROP TABLE IF EXISTS `Conta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Conta` (
  `ID_Conta` int NOT NULL AUTO_INCREMENT,
  `ID_Cliente` int NOT NULL,
  PRIMARY KEY (`ID_Conta`),
  KEY `ID_Cliente` (`ID_Cliente`),
  CONSTRAINT `Conta_ibfk_1` FOREIGN KEY (`ID_Cliente`) REFERENCES `Cliente` (`ID_Cliente`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Conta`
--

LOCK TABLES `Conta` WRITE;
/*!40000 ALTER TABLE `Conta` DISABLE KEYS */;
INSERT INTO `Conta` VALUES (4,4),(5,5),(6,6),(7,7),(8,8);
/*!40000 ALTER TABLE `Conta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Funcionario`
--

DROP TABLE IF EXISTS `Funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Funcionario` (
  `ID_Func` int NOT NULL AUTO_INCREMENT,
  `Login_Func` varchar(60) NOT NULL,
  `Senha_Func` varchar(30) NOT NULL,
  `CPF_P` char(11) NOT NULL,
  PRIMARY KEY (`ID_Func`),
  UNIQUE KEY `Login_Func` (`Login_Func`),
  KEY `CPF_P` (`CPF_P`),
  CONSTRAINT `Funcionario_ibfk_1` FOREIGN KEY (`CPF_P`) REFERENCES `Pessoa` (`CPF_P`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Funcionario`
--

LOCK TABLES `Funcionario` WRITE;
/*!40000 ALTER TABLE `Funcionario` DISABLE KEYS */;
INSERT INTO `Funcionario` VALUES (1,'R@tshop.com','123','16534655730'),(3,'a@tshop.com','123','06349391730');
/*!40000 ALTER TABLE `Funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Itens`
--

DROP TABLE IF EXISTS `Itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Itens` (
  `ID_Item` int NOT NULL AUTO_INCREMENT,
  `ID_Pdt` int NOT NULL,
  `ID_Pdd` int DEFAULT NULL,
  PRIMARY KEY (`ID_Item`),
  KEY `ID_Pdt` (`ID_Pdt`),
  KEY `ID_Pdd` (`ID_Pdd`),
  CONSTRAINT `Itens_ibfk_1` FOREIGN KEY (`ID_Pdt`) REFERENCES `Produto` (`ID_Pdt`),
  CONSTRAINT `Itens_ibfk_2` FOREIGN KEY (`ID_Pdd`) REFERENCES `Pedidos` (`ID_Pdd`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Itens`
--

LOCK TABLES `Itens` WRITE;
/*!40000 ALTER TABLE `Itens` DISABLE KEYS */;
INSERT INTO `Itens` VALUES (1,1,3),(2,1,3),(3,1,3),(4,1,3),(5,1,3),(6,1,4),(7,1,NULL),(8,1,NULL),(9,1,NULL),(10,1,NULL),(11,2,1),(12,2,2),(13,2,2),(14,2,2),(15,2,5),(16,2,6),(17,2,6),(18,2,7),(19,2,20),(20,2,21),(21,4,1),(22,4,1),(23,4,1),(24,4,1),(25,4,1),(26,6,NULL),(27,6,NULL),(28,6,NULL),(29,6,NULL),(30,6,NULL),(31,6,NULL),(32,1,NULL),(33,1,NULL),(34,1,NULL),(35,1,NULL),(36,1,NULL),(37,1,NULL),(38,1,NULL),(39,1,NULL),(40,1,NULL),(41,1,NULL),(42,2,21),(43,2,NULL),(44,2,NULL),(45,2,NULL),(46,2,NULL),(47,2,NULL),(48,2,NULL),(49,2,NULL),(50,2,NULL),(51,2,NULL),(52,2,NULL),(53,2,NULL),(54,2,NULL),(55,2,NULL),(56,2,NULL),(57,2,NULL),(58,2,NULL),(59,2,NULL);
/*!40000 ALTER TABLE `Itens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pagamentos`
--

DROP TABLE IF EXISTS `Pagamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Pagamentos` (
  `ID_Pgmt` int NOT NULL AUTO_INCREMENT,
  `ID_Pdd` int NOT NULL,
  `Tipo_Pgmt` varchar(30) NOT NULL,
  `Valor_Pgmt` double NOT NULL,
  `Data_Pgmt` date DEFAULT NULL,
  PRIMARY KEY (`ID_Pgmt`),
  KEY `ID_Pdd` (`ID_Pdd`),
  CONSTRAINT `Pagamentos_ibfk_1` FOREIGN KEY (`ID_Pdd`) REFERENCES `Pedidos` (`ID_Pdd`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pagamentos`
--

LOCK TABLES `Pagamentos` WRITE;
/*!40000 ALTER TABLE `Pagamentos` DISABLE KEYS */;
INSERT INTO `Pagamentos` VALUES (1,3,'Boleto',75,'2022-12-25'),(2,20,'Pix',10.9,'2022-12-25');
/*!40000 ALTER TABLE `Pagamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pedidos`
--

DROP TABLE IF EXISTS `Pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Pedidos` (
  `ID_Pdd` int NOT NULL AUTO_INCREMENT,
  `ID_Conta` int DEFAULT NULL,
  `Status_Pdd` varchar(30) NOT NULL,
  `Valor_Pdd` double NOT NULL,
  `Data_Pdd` date NOT NULL,
  PRIMARY KEY (`ID_Pdd`),
  KEY `ID_Conta` (`ID_Conta`),
  CONSTRAINT `Pedidos_ibfk_1` FOREIGN KEY (`ID_Conta`) REFERENCES `Conta` (`ID_Conta`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pedidos`
--

LOCK TABLES `Pedidos` WRITE;
/*!40000 ALTER TABLE `Pedidos` DISABLE KEYS */;
INSERT INTO `Pedidos` VALUES (1,NULL,'Cancelado',60.9,'2022-12-25'),(2,NULL,'Cancelado',32.7,'2022-12-25'),(3,NULL,'Finalizado',75,'2022-12-25'),(4,4,'Em processamento',15,'2022-12-25'),(5,4,'Finalizado',10.9,'2022-12-25'),(6,4,'Finalizado',21.8,'2022-12-25'),(7,4,'Finalizado',10.9,'2022-12-25'),(8,6,'Finalizado',30,'2022-01-14'),(9,6,'Finalizado',30,'2022-02-14'),(10,6,'Finalizado',30,'2022-03-14'),(11,6,'Finalizado',30,'2022-04-14'),(12,6,'Finalizado',30,'2022-05-14'),(13,6,'Finalizado',30,'2022-06-14'),(14,6,'Finalizado',30,'2022-07-14'),(15,6,'Finalizado',30,'2022-08-14'),(16,6,'Finalizado',30,'2022-09-14'),(17,6,'Finalizado',30,'2022-10-14'),(18,6,'Finalizado',30,'2022-11-14'),(19,6,'Finalizado',30,'2022-12-14'),(20,5,'Finalizado',10.9,'2022-12-25'),(21,7,'Confirmado',21.8,'2022-12-25');
/*!40000 ALTER TABLE `Pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pessoa`
--

DROP TABLE IF EXISTS `Pessoa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Pessoa` (
  `CPF_P` char(11) NOT NULL,
  `Nome_P` varchar(60) NOT NULL,
  `Telefone_P` char(11) NOT NULL,
  `Estado_P` char(2) NOT NULL,
  `Cidade_P` varchar(30) NOT NULL,
  `Bairro_P` varchar(30) NOT NULL,
  `Endereco_P` varchar(60) NOT NULL,
  `Email_P` varchar(60) DEFAULT NULL,
  `Nascimento_P` date NOT NULL,
  PRIMARY KEY (`CPF_P`),
  UNIQUE KEY `Telefone_P` (`Telefone_P`),
  UNIQUE KEY `Email_P` (`Email_P`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pessoa`
--

LOCK TABLES `Pessoa` WRITE;
/*!40000 ALTER TABLE `Pessoa` DISABLE KEYS */;
INSERT INTO `Pessoa` VALUES ('06349391730','Alvaro de Souza Ribeiro','22998360689','RJ','Petrópolis','Centro','Rua Washington 7',NULL,'2003-02-19'),('11111111111','Ana Marcela','22222222222','RJ','Petrópolis','Pequeno','Rua Azul 12','a@gmail.com','2000-01-01'),('16534655730','Raquel Guerreiro Zilves','24992264477','RJ','Centro','Petrópolis','Rua Paulo Barbosa 300','raquel.zilves@gmail.com','1997-08-25'),('22222222222','Gabriel Fernandes','11111111111','RJ','Bonita','Nobre','Rua Verde 60','g@gmail.com','2000-01-01'),('44444444444','Lucas Mota','44444444444','RN','Sulista','Centro','Rua Vermelha',NULL,'1986-07-14'),('93198621763','Thales Samuel','21973286981','RJ','Caioba','Nova Iguaçu','Travessa Rabi 12','t@gmail.com','1997-03-12'),('99999999999','Maria da Silva','99999999999','PE','Centro','Pequeno','Rua Amarela 20','m@gmail.com','2000-01-01');
/*!40000 ALTER TABLE `Pessoa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Produto`
--

DROP TABLE IF EXISTS `Produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Produto` (
  `ID_Pdt` int NOT NULL AUTO_INCREMENT,
  `Nome_Pdt` varchar(60) NOT NULL,
  `Preco_Pdt` double NOT NULL,
  `Descricao_Pdt` varchar(60) DEFAULT NULL,
  `Categoria_Pdt` char(1) NOT NULL,
  `Estoque_Pdt` int NOT NULL,
  PRIMARY KEY (`ID_Pdt`),
  CONSTRAINT `Produto_chk_1` CHECK ((`Preco_Pdt` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Produto`
--

LOCK TABLES `Produto` WRITE;
/*!40000 ALTER TABLE `Produto` DISABLE KEYS */;
INSERT INTO `Produto` VALUES (1,'Ração sabor Frango',15,'Saborosa','A',14),(2,'Ração sabor Carne',10.9,'Saborosa','A',17),(3,'Ração sabor Legumes',15,'Saborosa','A',0),(4,'Coleira',10,'Segura','B',0),(5,'Bola de borracha',3.99,'Não tóxica','B',0),(6,'Escova',7.99,'Para pentear','C',6),(7,'Casinha',30.7,'Confortável','C',0),(8,'Osso',14.99,'Orgânico','A',0),(9,'Petisco',6.99,'Saboroso','A',0);
/*!40000 ALTER TABLE `Produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'LojaRaquel'
--

--
-- Dumping routines for database 'LojaRaquel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-25 23:09:40
